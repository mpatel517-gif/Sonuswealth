import { useState } from 'react'

// FIX LOG:
// 1.1 — Multi-select circles looked like radio buttons (○ = single select).
//        Changed selector from borderRadius:'50%' to borderRadius:6 (rounded square = checkbox affordance).
// 1.2 — "☑ Select all that apply" badge was redundant with hint text and had wrong affordance.
//        Removed the badge. Hint text already says "Select all that apply".
// 1.3 — Continue button said "See my FQ dashboard →". Changed to "See my dashboard →".
// 1.4 — Hint on step 1 said "FQ score". Changed to "Finio Score".

const STAGES = [
  { n:1, name:'Foundation',    range:'18–30', c:'#4D8EFF' },
  { n:2, name:'Accumulation',  range:'30–45', c:'#00E5A8' },
  { n:3, name:'Consolidation', range:'45–55', c:'#FFB347' },
  { n:4, name:'Transition',    range:'55–65', c:'#FF8C42' },
  { n:5, name:'Decumulation',  range:'65–75', c:'#FF6B6B' },
  { n:6, name:'Preservation',  range:'75–85', c:'#9B59B6' },
  { n:7, name:'Legacy',        range:'85+',   c:'#7F8C8D' },
]

function stageFor(age) {
  if (age < 30) return STAGES[0]; if (age < 45) return STAGES[1]
  if (age < 55) return STAGES[2]; if (age < 65) return STAGES[3]
  if (age < 75) return STAGES[4]; if (age < 85) return STAGES[5]
  return STAGES[6]
}

const QUESTIONS = [
  {
    id:'age', label:'Step 1 of 3 · Your life stage',
    q:'How old are you?',
    // FIX 1.4: "FQ score" → "Finio Score"
    hint:'Your age determines which financial planning stage you\'re in and how Finio weights your Finio Score.',
    type:'slider',
  },
  {
    id:'focus', label:'Step 2 of 3 · Your goals',
    q:'What are your main financial priorities?',
    hint:'Select all that apply — Finio builds your dashboard around what matters most to you.',
    type:'multi',
    opts:[
      { ico:'📈', lbl:'Grow my wealth',         sub:'Investments, ISA, pension contributions' },
      { ico:'🏠', lbl:'Property planning',        sub:'Buy, remortgage, or release equity' },
      { ico:'🏖', lbl:'Retirement planning',      sub:'When can I retire? Will my money last?' },
      { ico:'🏛', lbl:'Reduce inheritance tax',   sub:'Protect what you leave behind' },
      { ico:'💼', lbl:'Business & tax planning',  sub:'Director, self-employed, or business owner' },
      { ico:'👨‍👩‍👧', lbl:'Family & protection',   sub:'Life cover, income protection, children\'s futures' },
      { ico:'🌍', lbl:'Cross-border finances',    sub:'Assets or income in multiple countries' },
      { ico:'📊', lbl:'Investment portfolio',     sub:'Stocks, ETFs, commodities, alternatives' },
    ],
  },
  {
    id:'setup', label:'Step 3 of 3 · Your profile',
    q:'What best describes your situation?',
    hint:'This shapes the intelligence layer behind your dashboard — select all that apply.',
    type:'multi',
    opts:[
      { ico:'👤', lbl:'I manage my own finances',    sub:'Self-directed — no adviser' },
      { ico:'👫', lbl:'Planning as a couple',         sub:'Combine household allowances and planning' },
      { ico:'👔', lbl:'I have a financial adviser',   sub:'Share your Finio dashboard with your IFA' },
      { ico:'🏢', lbl:'I run a business',             sub:'Director, sole trader, or partnership' },
      { ico:'📊', lbl:'I am a financial adviser',     sub:'Access the IFA professional dashboard' },
      { ico:'🏦', lbl:'I manage client portfolios',   sub:'Practice intelligence and client FQ tracking' },
    ],
  },
]

export default function Onboarding({ onComplete, onBack }) {
  const [step, setStep]   = useState(0)
  const [age,  setAge]    = useState(38)
  const [sels, setSels]   = useState({ focus: [], setup: [] })

  const q     = QUESTIONS[step]
  const total = QUESTIONS.length
  const stage = stageFor(age)
  const isLast = step === total - 1

  function canContinue() {
    if (q.type === 'slider') return true
    return (sels[q.id]?.length || 0) > 0
  }

  function toggleOpt(qid, idx) {
    setSels(s => {
      const arr = [...(s[qid] || [])]
      const i = arr.indexOf(idx)
      if (i >= 0) arr.splice(i, 1); else arr.push(idx)
      return { ...s, [qid]: arr }
    })
  }

  function next() {
    if (step < total - 1) setStep(s => s + 1)
    else onComplete({ age, ...sels })
  }

  function back() {
    if (step === 0) onBack()
    else setStep(s => s - 1)
  }

  return (
    <div style={{ position:'absolute', inset:0, background:'var(--c-bg)', display:'flex', flexDirection:'column', overflow:'hidden' }}>

      {/* Header */}
      <div style={{ padding:'56px 24px 16px', background:'var(--c-bg)', flexShrink:0 }}>
        {/* Progress pips */}
        <div style={{ display:'flex', gap:5, marginBottom:20 }}>
          {Array.from({ length: total }, (_, i) => (
            <div key={i} style={{
              height:3, flex:1, borderRadius:100,
              background: i < step ? 'var(--c-acc)' : i === step ? 'var(--c-text2)' : 'var(--c-surface3)',
              transition:'background .3s ease',
            }} />
          ))}
        </div>
        <div style={{ fontSize:11, fontWeight:600, color:'var(--c-text3)', textTransform:'uppercase', letterSpacing:1, marginBottom:8 }}>
          {q.label}
        </div>
        <div style={{ fontSize:26, fontWeight:800, color:'var(--c-text)', lineHeight:1.2, letterSpacing:-.5 }}>
          {q.q}
        </div>
        {q.hint && (
          <div style={{ fontSize:13, color:'var(--c-text3)', marginTop:6, lineHeight:1.5 }}>{q.hint}</div>
        )}
      </div>

      {/* Body */}
      <div style={{ flex:1, overflowY:'auto', padding:'16px 24px', WebkitOverflowScrolling:'touch' }}>

        {q.type === 'slider' && (
          <div>
            <div style={{ textAlign:'center', padding:'24px 0 28px' }}>
              <div style={{ fontSize:96, fontWeight:800, color:'var(--c-text)', letterSpacing:-5, lineHeight:1 }}>
                {age}<span style={{ fontSize:22, fontWeight:400, color:'var(--c-text3)' }}> yrs</span>
              </div>
              <div style={{
                display:'inline-flex', alignItems:'center', gap:8, marginTop:12,
                background:'var(--c-surface)', border:'1px solid var(--c-border2)',
                borderRadius:100, padding:'7px 16px',
                fontSize:13, fontWeight:600, color:'var(--c-text2)',
              }}>
                <div style={{ width:9, height:9, borderRadius:'50%', background: stage.c }} />
                Stage {stage.n} · {stage.name} · {stage.range}
              </div>
            </div>
            <input
              type="range" min="18" max="85" value={age}
              onChange={e => setAge(parseInt(e.target.value))}
              style={{ width:'100%' }}
            />
            <div style={{ display:'flex', justifyContent:'space-between', marginTop:8, fontSize:11, color:'var(--c-text3)' }}>
              <span>18</span><span>85+</span>
            </div>
          </div>
        )}

        {q.type === 'multi' && (
          <div>
            {/* FIX 1.2: Removed redundant "☑ Select all that apply" badge.
                Hint text already communicates this clearly. */}
            <div style={{ display:'flex', flexDirection:'column', gap:8, marginTop:4 }}>
              {q.opts.map((o, i) => {
                const sel = sels[q.id]?.includes(i)
                return (
                  <div key={i} onClick={() => toggleOpt(q.id, i)} style={{
                    display:'flex', alignItems:'center', gap:14, padding:'14px 18px',
                    background: sel ? 'var(--c-acc2-bg)' : 'var(--c-surface)',
                    border: `1.5px solid ${sel ? 'var(--c-acc2)' : 'var(--c-border)'}`,
                    borderRadius:16, cursor:'pointer',
                    transition:'all .15s ease',
                  }}>
                    <div style={{
                      width:44, height:44, borderRadius:12,
                      background: sel ? 'rgba(77,142,255,.15)' : 'var(--c-surface2)',
                      display:'flex', alignItems:'center', justifyContent:'center',
                      fontSize:20, flexShrink:0,
                    }}>
                      {o.ico}
                    </div>
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:15, fontWeight:600, color:'var(--c-text)', marginBottom:2 }}>{o.lbl}</div>
                      <div style={{ fontSize:11, color:'var(--c-text3)', lineHeight:1.4 }}>{o.sub}</div>
                    </div>
                    {/* FIX 1.1: borderRadius changed from '50%' (radio/circle) to 6 (checkbox/square).
                        Multi-select affordance = square; single-select = circle. */}
                    <div style={{
                      width:22, height:22, borderRadius:6, flexShrink:0,
                      border: `1.5px solid ${sel ? 'var(--c-acc2)' : 'var(--c-border2)'}`,
                      background: sel ? 'var(--c-acc2)' : 'transparent',
                      display:'flex', alignItems:'center', justifyContent:'center',
                      transition:'all .15s ease',
                    }}>
                      {sel && (
                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                          <path d="M2 6l3 3 5-5" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div style={{
        padding:'16px 24px', paddingBottom:'max(16px,env(safe-area-inset-bottom))',
        background:'var(--c-bg)', borderTop:'1px solid var(--c-border)', flexShrink:0,
      }}>
        <div style={{ display:'flex', gap:8 }}>
          <button onClick={back} style={{
            width:50, height:50, borderRadius:14,
            background:'var(--c-surface)', border:'1px solid var(--c-border2)',
            color:'var(--c-text2)', fontSize:18,
            display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0,
          }}>←</button>
          <button onClick={next} disabled={!canContinue()} style={{
            flex:1, padding:15,
            background: canContinue() ? (isLast ? 'var(--c-acc)' : 'var(--c-text)') : 'var(--c-surface2)',
            color: canContinue() ? (isLast ? '#0B1F3A' : 'var(--c-bg)') : 'var(--c-text3)',
            border: `1px solid ${canContinue() ? 'transparent' : 'var(--c-border2)'}`,
            borderRadius:100, fontSize:16, fontWeight:700,
            transition:'all .2s ease',
            boxShadow: isLast && canContinue() ? 'var(--sh-acc)' : 'none',
          }}>
            {/* FIX 1.3: "See my FQ dashboard →" → "See my dashboard →" */}
            {isLast ? 'See my dashboard →' : 'Continue →'}
          </button>
        </div>
      </div>
    </div>
  )
}
