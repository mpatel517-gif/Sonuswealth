import { useState, useRef, useEffect } from 'react'
import { fmt, daysLeft, netWorth, costOfInaction, calcFQ } from '../engine/fq-calculator.js'
import { calcRisk } from '../engine/fq-calculator.js'
import { BRAND } from '../config/brand.js'

// FIX 7.1: API key moved from hardcoded string to environment variable.
// Create a file called .env in your project root (C:\Users\Mihir Patel.Mihir\Desktop\finio\.env)
// with this line:
//   VITE_ANTHROPIC_KEY=sk-ant-api03-...your-key-here...
// Then add .env to your .gitignore so it is never pushed to GitHub.
// The key will not be visible in source code or git history.
const API_KEY = import.meta.env.VITE_ANTHROPIC_KEY || ''

// ── Dynamic system prompt — built from entity data ────────────────────────
function buildSystemPrompt(entity) {
  const fq   = calcFQ(entity)
  const nw   = netWorth(entity)
  const coi  = costOfInaction(entity)
  const days = daysLeft()
  const a    = entity.assets || {}
  const prot = a.protection || {}
  const inc  = entity.income || {}
  const liab = entity.liabilities || {}

  let risk = null
  try { risk = calcRisk(entity) } catch {}

  const protLines = [
    prot.lifeInsurance?.exists
      ? `Life insurance ${fmt(prot.lifeInsurance.amount||0)}${prot.lifeInsurance.inTrust ? ' (in trust ✓)' : ' (NOT in trust — adds to estate)'}`
      : 'No life insurance',
    prot.criticalIllness?.exists
      ? `Critical illness cover ${fmt(prot.criticalIllness.amount||0)}`
      : 'No critical illness cover',
    prot.incomeProtection?.exists
      ? 'Income protection in place'
      : 'No income protection',
  ].join(' · ')

  const liabLines = []
  if (liab.mortgage?.outstanding > 0)
    liabLines.push(`Mortgage ${fmt(liab.mortgage.outstanding)} (${liab.mortgage.rateType} rate, ${liab.mortgage.remainingYears} years remaining)`)
  ;(liab.otherLoans || []).forEach(l => liabLines.push(`${l.type || 'Loan'} ${fmt(l.outstanding)}`))
  const liabStr = liabLines.length ? liabLines.join(' · ') : 'No debt'

  const deadline = coi > 0 && days < 500
    ? `\nCRITICAL DEADLINE: DC pension enters estate for IHT in ${days} days (6 April 2027). Cost of inaction: ${fmt(coi)}.`
    : ''

  return `You are Finio AI — a financial planning intelligence assistant. You are NOT a regulated financial adviser. You provide financial planning guidance and education only. Always end tax-related answers with: "Verify with a qualified FCA-authorised adviser."

PERSON: ${entity.name}, age ${entity.age || '?'}, ${entity.lifeStageName || ''} stage.
${entity.isIFA ? 'ROLE: Independent Financial Adviser. Context: practice management and client intelligence.' : ''}
${entity.isCouple ? 'HOUSEHOLD: Couple account.' : ''}

FINIO SCORE: ${fq.total}/100 · ${fq.band.name} (momentum ${fq.momentum?.toFixed(2) || '1.00'})
${risk ? `RISK SCORE: ${risk.total}/100 · ${risk.band.name} (confidence: ${risk.confidenceLevel || 'low'})` : ''}
NET WORTH: ${fmt(nw)}

ASSETS:
- Pension (SIPP/DC): ${fmt(a.sipp?.total || 0)} across ${a.sipp?.pensions?.length || 0} pension(s)
- ISA: ${fmt(a.isa?.value || 0)}
- Property: ${fmt((a.residence?.value||0)*(a.residence?.ownershipShare||1))}
- Portfolio/GIA: ${fmt(a.portfolio?.value || 0)}${a.portfolio?.bpr ? ' (BPR qualifying)' : ''}
- Cash: ${fmt(a.cash?.total || 0)}
${a.trustGifts ? `- Trust gifts: ${fmt(a.trustGifts.total)} (gifted ${a.trustGifts.date})` : ''}

INCOME:
- Employment: ${fmt(inc.employment || 0)}/yr
- Dividends: ${fmt(inc.dividends || 0)}/yr
- State Pension: ${fmt(inc.statePension?.annual || 0)}/yr from age ${inc.statePension?.startAge || 67}
- Current drawdown: ${fmt(entity.drawdown || 0)}/yr

PROTECTION: ${protLines}
LIABILITIES: ${liabStr}
WILL: ${entity.willStatus || 'not recorded'} · LPA: ${entity.lpaStatus || 'not recorded'}
${deadline}

RULES: UK-2026.1 verified April 2026. Personal allowance £12,570. Basic rate band £37,700. IHT nil-rate band £325,000. RNRB £175,000. IHT rate 40%.

Respond in 3–4 sentences maximum. Be direct. Use their actual numbers. End with one bold recommended action. Offer 3 follow-up questions.`
}

// ── Dynamic opening message ───────────────────────────────────────────────
function getOpeningMessage(entity) {
  const fq   = calcFQ(entity)
  const days = daysLeft()
  const coi  = costOfInaction(entity)
  const name = (entity.name || 'there').split(' ')[0]
  const sipp = entity.assets?.sipp?.total || 0

  let urgentLine
  if (coi > 0 && days < 500 && sipp > 0) {
    urgentLine = `\n\nThe most urgent thing in your financial picture: your pension of ${fmt(sipp)} enters your estate for inheritance tax in **${days} days**. The cost of waiting is **${fmt(coi)}**.`
  } else if (entity.isIFA) {
    urgentLine = `\n\nYou have ${entity.clientSummary?.length || 0} clients loaded. Ask me about any of them, or about your practice position.`
  } else {
    urgentLine = `\n\nYour **${fq.band.name}** score means ${
      fq.band.name === 'Exceptional' ? 'you are in excellent financial health — ask me what to protect.' :
      fq.band.name === 'Optimised'   ? 'you are doing well — ask me what the remaining opportunities are.' :
      fq.band.name === 'Established' ? 'your foundations are solid — ask me what moves you to the next level.' :
      fq.band.name === 'Building'    ? 'you are making good progress — ask me what to prioritise.' :
      'there are clear actions that will move this number quickly — ask me where to start.'
    }`
  }

  return `Hello ${name}. Your Finio Score is **${fq.total}/100 · ${fq.band.name}**.${urgentLine}\n\nWhat would you like to explore?`
}

// ── Demo fallback responses ───────────────────────────────────────────────
function getDemoResponse(question, entity) {
  const q    = question.toLowerCase()
  const fq   = calcFQ(entity)
  const coi  = costOfInaction(entity)
  const days = daysLeft()
  const sipp = entity.assets?.sipp?.total || 0

  if (q.includes('score') || q.includes('finio') || q.includes('dimension')) {
    return {
      text: `Your Finio Score of **${fq.total}/100** is in the **${fq.band.name}** band. The three dimensions with the most room to improve are: Estate (the pension deadline is the single biggest lever), Protection (no cover in place), and Tax Efficiency (allowances available). **Start pension drawdown this tax year — this is the highest-leverage action.**`,
      followUps: ['What moves my score most?', 'How is my score calculated?', 'What does each dimension mean?'],
    }
  }
  if (q.includes('pension') || q.includes('drawdown') || q.includes('sipp')) {
    return {
      text: `Your pension of **${fmt(sipp)}** will be subject to 40% IHT from April 2027 — **${days} days from now**. Drawing £37,700/year keeps you within the basic rate band and generates approximately £29,000/year net after income tax. **Model the three drawdown scenarios on the Tax & Estate screen now.**`,
      followUps: ['What is the optimal drawdown amount?', 'How much tax will I pay on drawdown?', 'Should I consolidate my pensions first?'],
    }
  }
  if (q.includes('iht') || q.includes('inheritance') || q.includes('estate')) {
    return {
      text: `The cost of inaction is **${fmt(coi)}** — that is the extra IHT your estate pays by not starting drawdown before April 2027. Your nil-rate band and RNRB are your main shields on the property side. **Every month of pension drawdown reduces both the pot and the IHT exposure simultaneously.**`,
      followUps: ['How can I reduce my IHT?', 'What is the 7-year gift rule?', 'Should I increase my gifting?'],
    }
  }
  if (q.includes('risk') || q.includes('resilience') || q.includes('protection')) {
    let risk = null
    try { risk = calcRisk(entity) } catch {}
    return {
      text: `${risk ? `Your Risk Score is **${risk.total}/100 · ${risk.band.name}**. ` : ''}Your biggest resilience gaps are: Protection Coverage (no insurance in place means a serious illness or early death leaves the estate exposed) and Dependency Exposure (no LPA registered). **Addressing protection first has the highest combined impact on both your Finio and Risk scores.**`,
      followUps: ['What insurance do I need?', 'What is an LPA and why does it matter?', 'What are shock scenarios?'],
    }
  }
  return {
    text: `The most important action right now is to **start pension drawdown before April 2027**. Your Finio Score is **${fq.total}/100 · ${fq.band.name}**. The cost of waiting is **${fmt(coi)}**. Open the Tax & Estate screen to model your options and see the live IHT impact.`,
    followUps: ['What is my biggest financial risk?', 'How do I improve my Finio Score?', 'What should I do this tax year?'],
  }
}

// ── Bubble ────────────────────────────────────────────────────────────────
function Bubble({ msg }) {
  const isUser = msg.role === 'user'
  // Render **bold** markdown simply
  const parts = msg.content.split(/(\*\*[^*]+\*\*)/g)
  return (
    <div style={{
      display:'flex', justifyContent: isUser ? 'flex-end' : 'flex-start',
      marginBottom:12,
    }}>
      <div style={{
        maxWidth:'85%', padding:'10px 14px',
        background: isUser ? 'var(--c-acc2)' : 'var(--c-surface)',
        border: isUser ? 'none' : '1px solid var(--c-sep)',
        borderRadius: isUser ? '18px 18px 4px 18px' : '18px 18px 18px 4px',
        fontSize:14, lineHeight:1.6,
        color: isUser ? '#fff' : 'var(--c-text)',
      }}>
        {parts.map((p, i) =>
          p.startsWith('**') && p.endsWith('**')
            ? <strong key={i}>{p.slice(2,-2)}</strong>
            : p
        )}
      </div>
    </div>
  )
}

function Typing() {
  return (
    <div style={{ display:'flex', gap:6, padding:'8px 14px', marginBottom:12 }}>
      {[0,1,2].map(i => (
        <div key={i} style={{
          width:8, height:8, borderRadius:'50%',
          background:'var(--c-text3)',
          animation:`bounce 1s ease-in-out infinite ${i*0.15}s`,
        }} />
      ))}
    </div>
  )
}

function Chips({ suggestions, onTap }) {
  return (
    <div style={{ display:'flex', flexWrap:'wrap', gap:8, marginBottom:12 }}>
      {suggestions.map((s, i) => (
        <button key={i} onClick={() => onTap(s)} style={{
          padding:'7px 14px', borderRadius:100,
          background:'var(--c-surface)', border:'1px solid var(--c-sep)',
          fontSize:13, color:'var(--c-text2)', cursor:'pointer',
          transition:'border-color .15s',
        }}>
          {s}
        </button>
      ))}
    </div>
  )
}

// Dimension labels for the "Ask AI about X" entry prompt
const DIM_LABELS = {
  behaviour: 'Behaviour', capital: 'Capital', tax: 'Tax',
  protection: 'Protection', cashflow: 'Cashflow',
  debt: 'Debt', estate: 'Estate',
}

export default function Ask({ entity, context, onClearContext }) {
  const opening = getOpeningMessage(entity)
  const [messages, setMessages] = useState([{ role:'assistant', content: opening }])
  const [input, setInput]       = useState('')
  const [loading, setLoading]   = useState(false)
  const [chips, setChips]       = useState(entity.aiSuggestions || ['What moves my Finio Score most?','Explain my pension inheritance tax risk','Should I start drawdown now?','How do I improve my tax efficiency?'])
  const bottomRef = useRef(null)
  const inputRef  = useRef(null)

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior:'smooth' }) }, [messages, loading])

  // D05 fix: when arriving with a dim context (from SimulatorPanel's "Ask AI
  // about [dim]" button), seed an opening question for that dimension and
  // clear the context so the same prompt doesn't re-fire on unrelated renders.
  useEffect(() => {
    if (!context?.dimKey) return
    const label = DIM_LABELS[context.dimKey] || context.dimKey
    const dimQ  = `Explain my ${label} score — what drives it, and what action would improve it most?`
    setMessages(prev => [
      ...prev,
      { role:'user',      content: dimQ },
      { role:'assistant', content: `Let me walk you through your **${label}** score for ${entity.name || 'this profile'}. (Pulling from your current data…) — this is a stub response for Session 1; the AI layer wires to the engine in a future session.` },
    ])
    setChips([
      `How much can I improve ${label} by?`,
      `What's the single biggest ${label} action I should take?`,
      `How does ${label} interact with my other dimensions?`,
    ])
    onClearContext?.()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [context])

  async function send(text) {
    const q = (text || input).trim()
    if (!q) return
    setInput('')
    setChips([])
    const userMsg = { role:'user', content:q }
    setMessages(prev => [...prev, userMsg])
    setLoading(true)

    try {
      const history = [...messages, userMsg].map(m => ({ role:m.role, content:m.content }))
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': API_KEY,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          system: buildSystemPrompt(entity),
          messages: history,
        }),
      })
      if (!res.ok) throw new Error('api error')
      const data = await res.json()
      const replyText = data.content?.find(b => b.type === 'text')?.text || ''
      setMessages(prev => [...prev, { role:'assistant', content: replyText }])
      setChips(['Ask something else', 'Explain this further', 'What should I do next?'])
    } catch {
      const demo = getDemoResponse(q, entity)
      setTimeout(() => {
        setMessages(prev => [...prev, { role:'assistant', content: demo.text }])
        setChips(demo.followUps)
        setLoading(false)
      }, 900)
      return
    }
    setLoading(false)
  }

  return (
    <div style={{ flex:1, display:'flex', flexDirection:'column', height:'100%', overflow:'hidden' }}>
      <div style={{ textAlign:'right', fontSize:11, color:'var(--c-text3)', padding:'6px 16px 0' }}>
        Rules: UK-2026.1 · Data: April 2026
      </div>
      <div style={{ flex:1, overflowY:'auto', padding:'12px 16px' }}>
        {messages.map((m, i) => <Bubble key={i} msg={m} />)}
        {loading && <Typing />}
        {!loading && chips.length > 0 && <Chips suggestions={chips} onTap={t => { setInput(''); send(t) }} />}
        <div ref={bottomRef} />
      </div>
      <div style={{ padding:'10px 16px 32px', background:'var(--c-bg)', borderTop:'1px solid var(--c-sep)', flexShrink:0 }}>
        <div style={{ display:'flex', gap:8, alignItems:'center' }}>
          <input
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !loading && send()}
            placeholder="Ask anything about your financial position…"
            style={{ flex:1, background:'var(--c-surface)', border:'1px solid var(--c-sep)', borderRadius:100, padding:'11px 16px', fontSize:14, color:'var(--c-text)', outline:'none' }}
          />
          <button
            onClick={() => !loading && send()}
            disabled={loading || !input.trim()}
            style={{ width:42, height:42, borderRadius:'50%', background: input.trim() ? 'var(--c-acc)' : 'var(--c-surface2)', color: input.trim() ? '#000' : 'var(--c-text3)', border:'none', fontSize:18, cursor: input.trim() ? 'pointer' : 'default', flexShrink:0, transition:'all 0.2s' }}
          >→</button>
        </div>
        <div style={{ fontSize:11, color:'var(--c-text3)', textAlign:'center', marginTop:6 }}>
          Not regulated financial advice · Verify decisions with a qualified FCA-authorised adviser
        </div>
      </div>
      <style>{`
        @keyframes bounce {
          0%,100% { transform: translateY(0); opacity: 0.4 }
          50%      { transform: translateY(-4px); opacity: 1 }
        }
      `}</style>
    </div>
  )
}
