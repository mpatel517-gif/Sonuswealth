// ─────────────────────────────────────────────────────────────────────────────
// MyMoney.jsx — Session 1 rewrite (22 April 2026)
// ─────────────────────────────────────────────────────────────────────────────
// Changes vs prior:
//   · Pension category tap → new PensionDrillDown overlay (DQ-43 / D07)
//     — five-statement spec partially surfaced: Balance Sheet Layer 3 for
//       the pension branch, with scenario capability via schedule editor
//   · PensionDrillDown uses OverlayShell for consistent nav (D08)
//   · Multi-phase drawdown schedule editor (D01 / DQ-45)
//   · Nominations review with stale flag (D14)
//   · Commit path via event store (D06)
// Unchanged:
//   · Main MyMoney view (net-worth hero, prop bar, cats, income, cashflow)
//   · LineItemSheet bottom sheet for non-pension cats (read-only Layer 3)
// ─────────────────────────────────────────────────────────────────────────────

import { useState, useMemo } from 'react'
import {
  fmt, netWorth, guardrail, sippProjection, sippProjectionSeries,
  ihtDynamic, costOfInaction, nominationStatus,
} from '../engine/fq-calculator.js'
import { BRAND } from '../config/brand.js'
import OverlayShell from '../components/shared/OverlayShell.jsx'
import { EV } from '../state/events.jsx'

// ─── Build asset categories ────────────────────────────────────────────────
function buildCategories(entity) {
  const a    = entity.assets  || {}
  const liab = entity.liabilities || {}

  const sippTotal    = a.sipp?.total || 0
  const isaVal       = a.isa?.value  || 0
  const propVal      = (a.residence?.value || 0) * (a.residence?.ownershipShare || 1)
  const portVal      = a.portfolio?.value || 0
  const cashTotal    = a.cash?.total || 0
  const mortgageOut  = liab.mortgage?.outstanding || 0
  const otherDebt    = (liab.otherLoans || []).reduce((s, l) => s + (l.outstanding || 0), 0)

  const totalAssets  = sippTotal + isaVal + propVal + portVal + cashTotal
  const totalLiab    = mortgageOut + otherDebt

  const cats = [
    {
      id:'pension', label:'Pension', colour:'#4D8EFF',
      icon:'🏦', value: sippTotal,
      drillType: 'pension',    // ← new: routes to PensionDrillDown
      items: (a.sipp?.pensions || []).map(p => ({
        label: p.name, value: p.value,
        sub: `${p.provider} · ${p.type} · ${(p.charge*100).toFixed(2)}% charge`,
        note: p.nominationDate ? `Nominated ${p.nominationDate}` : 'No beneficiary named',
      })),
    },
    {
      id:'isa', label:'ISA', colour:'#00E5A8',
      icon:'🌱', value: isaVal,
      items: isaVal > 0 ? [{ label:'Stocks & Shares ISA', value: isaVal,
        sub:`Growing at ${(a.isa?.growth||0.05)*100}% p.a.`, note:'Tax-free wrapper' }] : [],
    },
    {
      id:'property', label:'Property', colour:'#FF9500',
      icon:'🏠', value: propVal,
      items: propVal > 0 ? [{ label: a.residence?.address || 'Primary residence',
        value: propVal, sub:`${(a.residence?.ownershipShare||1)*100}% ownership share`,
        note:'Included in estate for IHT' }] : [],
    },
    {
      id:'portfolio', label:'Portfolio', colour:'#AF52DE',
      icon:'📊', value: portVal,
      items: portVal > 0 ? [
        { label:'GIA / Investment Portfolio', value: portVal,
          sub: a.portfolio?.bpr ? 'BPR qualifying — IHT exempt' : 'General Investment Account',
          note: a.portfolio?.bpr ? '100% IHT relief after 2 years' : 'Capital gains apply' },
        ...(entity.etfs||[]).map(e => ({
          label: `${e.ticker} — ${e.name}`,
          value: null,
          sub: e.val,
          note: `${e.pct} since purchased`,
          up: e.up,
        })),
      ] : [],
    },
    {
      id:'cash', label:'Cash & Savings', colour:'#34C759',
      icon:'💧', value: cashTotal,
      items: cashTotal > 0 ? [{ label:'Accessible savings',
        value: a.cash?.own || cashTotal,
        sub:`${((a.cash?.rate||0.04)*100).toFixed(1)}% interest rate`,
        note:`${Math.round(((a.cash?.own||cashTotal) / ((entity.targetIncome||50000)/12)))} months essential expenses` }] : [],
    },
  ]

  const liabCat = {
    id:'liabilities', label:'Liabilities', colour:'#FF6B6B',
    icon:'⚖', value: totalLiab,
    isLiability: true,
    items: [
      ...(mortgageOut > 0 ? [{
        label:`Mortgage — ${liab.mortgage?.rateType==='variable'?'variable':'fixed'} rate`,
        value: mortgageOut,
        sub:`${fmt(liab.mortgage?.monthlyPayment||0)}/month · ${liab.mortgage?.remainingYears||0} years remaining`,
        note:`${(liab.mortgage?.rate||0)*100}% interest rate`,
      }] : []),
      ...(liab.otherLoans||[]).map(l => ({
        label: l.type?.replace(/_/g,' ') || 'Loan',
        value: l.outstanding,
        sub: `${fmt(l.monthlyPayment)}/month`,
        note: `${(l.rate||0)*100}% interest`,
      })),
    ],
  }

  return { cats: cats.filter(c => c.value > 0), liabCat, totalAssets, totalLiab, nw: netWorth(entity) }
}

// ─── Proportional bar ─────────────────────────────────────────────────────
function PropBar({ cats, total }) {
  if (!total || total <= 0) return null
  return (
    <div style={{ height:10, borderRadius:100, overflow:'hidden',
      display:'flex', marginBottom:16, gap:2 }}>
      {cats.map(c => (
        <div key={c.id} style={{
          flex: c.value / total,
          background: c.colour,
          opacity: 0.9,
          minWidth: c.value > 0 ? 4 : 0,
          transition: 'flex 0.6s cubic-bezier(0.4,0,0.2,1)',
        }} />
      ))}
    </div>
  )
}

// ─── Category row ─────────────────────────────────────────────────────────
function CatRow({ cat, total, onTap }) {
  const pct = total > 0 ? Math.round((cat.value / total) * 100) : 0
  return (
    <div className="tree-row" onClick={() => cat.items.length > 0 && onTap(cat)}>
      <div style={{ display:'flex', alignItems:'center', gap:12, flex:1 }}>
        <div style={{ width:36, height:36, borderRadius:10,
          background:`${cat.colour}18`, display:'flex', alignItems:'center',
          justifyContent:'center', fontSize:17, flexShrink:0 }}>
          {cat.icon}
        </div>
        <div style={{ flex:1 }}>
          <div style={{ fontSize:14, fontWeight:600, color:'var(--c-text)',
            marginBottom:4 }}>{cat.label}</div>
          <div style={{ height:4, background:'rgba(255,255,255,.07)',
            borderRadius:100, overflow:'hidden' }}>
            <div style={{ width:`${pct}%`, height:'100%',
              background:cat.colour, borderRadius:100 }} />
          </div>
        </div>
      </div>
      <div style={{ textAlign:'right', paddingLeft:12 }}>
        <div style={{ fontSize:15, fontWeight:700,
          color: cat.isLiability ? '#FF6B6B' : 'var(--c-text)' }}>
          {cat.isLiability ? '−' : ''}{fmt(cat.value)}
        </div>
        <div style={{ fontSize:11, color:'var(--c-text3)', marginTop:1 }}>
          {pct}%
        </div>
      </div>
      {cat.items.length > 0 && (
        <div style={{ fontSize:14, color:'var(--c-text3)',
          paddingLeft:6, flexShrink:0 }}>›</div>
      )}
    </div>
  )
}

// ─── Line item bottom sheet (Layer 3 read-only for non-pension cats) ─────
function LineItemSheet({ cat, onClose }) {
  if (!cat) return null
  return (
    <div className="sheet-overlay">
      <div className="sheet-backdrop" onClick={onClose} />
      <div className="sheet-panel">
        <div className="sheet-handle" />
        <div style={{ display:'flex', alignItems:'center', gap:12,
          marginBottom:16 }}>
          <div style={{ width:44, height:44, borderRadius:12,
            background:`${cat.colour}18`, display:'flex', alignItems:'center',
            justifyContent:'center', fontSize:20 }}>
            {cat.icon}
          </div>
          <div>
            <div style={{ fontSize:17, fontWeight:800, color:'var(--c-text)' }}>
              {cat.label}
            </div>
            <div style={{ fontSize:13, color:cat.colour, fontWeight:600 }}>
              {cat.isLiability ? '−' : ''}{fmt(cat.value)} total
            </div>
          </div>
        </div>
        {cat.items.map((item, i) => (
          <div key={i} style={{ padding:'12px 0',
            borderBottom: i < cat.items.length-1 ? '1px solid var(--c-sep)' : 'none' }}>
            <div style={{ display:'flex', justifyContent:'space-between',
              alignItems:'flex-start', marginBottom:4 }}>
              <div style={{ fontSize:13, fontWeight:600, color:'var(--c-text)',
                flex:1, marginRight:12 }}>
                {item.label}
              </div>
              {item.value !== null && item.value !== undefined && (
                <div style={{ fontSize:14, fontWeight:700,
                  color: item.up === false ? '#FF6B6B' : item.up ? '#00E5A8' : 'var(--c-text)' }}>
                  {item.up !== undefined ? item.sub : fmt(item.value)}
                </div>
              )}
            </div>
            {item.up === undefined && (
              <div style={{ fontSize:12, color:'var(--c-text2)', marginBottom:2 }}>
                {item.sub}
              </div>
            )}
            {item.note && (
              <div style={{ fontSize:11, color:'var(--c-text3)', fontStyle:'italic' }}>
                {item.note}
              </div>
            )}
          </div>
        ))}
        <button onClick={onClose} style={{ width:'100%', marginTop:16,
          background:'var(--c-acc2)', color:'#fff', border:'none',
          borderRadius:100, padding:'13px 0', fontSize:14, fontWeight:700,
          cursor:'pointer' }}>
          Done
        </button>
      </div>
    </div>
  )
}

// ─── PensionDrillDown — Layer 3 scenario for the pension branch ────────────
// Implements the multi-phase drawdown schedule spec:
//   [{ age, amount, reason? }, ...]
// User can edit any row inline; chart + IHT update live; commit writes the
// schedule back as an event.
function PensionDrillDown({ entity, personaId, onBack, onHome, onCommit }) {
  const a        = entity.assets || {}
  const sippTot  = a.sipp?.total || 0
  const growth   = a.sipp?.growth || 0.05
  const currentAge = entity.age || 62
  const guard    = Math.round(guardrail(entity))

  // Seed schedule: prefer committed one from entity, else default-empty 5 years
  const committedSchedule = entity.drawdownSchedule
  const [schedule, setSchedule] = useState(() => {
    if (Array.isArray(committedSchedule) && committedSchedule.length > 0) {
      return committedSchedule.map(r => ({ ...r }))
    }
    // Default: 5 years starting next year at £0
    return Array.from({ length: 5 }, (_, i) => ({
      age: currentAge + 1 + i,
      amount: entity.drawdown || 0,
      reason: null,
    }))
  })

  // ─── Quick presets ────────────────────────────────────────────────────
  const presets = [
    { id: 'none',   label: 'Do nothing',   make: () => schedule.map(r => ({ ...r, amount: 0 })) },
    { id: 'basic',  label: 'Basic-rate £37,700/yr', make: () => schedule.map(r => ({ ...r, amount: 37700 })) },
    { id: 'guard',  label: `Guardrail ${fmt(guard)}/yr`, make: () => schedule.map(r => ({ ...r, amount: guard })) },
  ]

  // ─── Engine-driven previews ──────────────────────────────────────────
  const yearsAhead = schedule.length
  const endValue   = sippProjection(sippTot, growth, schedule, yearsAhead)
  const series     = sippProjectionSeries(sippTot, growth, schedule, yearsAhead, currentAge)

  // IHT impact: simulate with this schedule's first-year draw (IHT-at-death
  // snapshot uses year-1 value per current engine)
  const ihtWithSchedule    = ihtDynamic({ ...entity, drawdown: schedule[0]?.amount || 0 }, true).iht
  const ihtCurrent         = ihtDynamic(entity, true).iht
  const ihtDelta           = ihtCurrent - ihtWithSchedule
  const coiCurrent         = costOfInaction(entity)

  // Detect change vs committed (or vs no-draw baseline)
  const baselineSchedule   = committedSchedule || schedule.map(r => ({ ...r, amount: 0 }))
  const isDirty = schedule.some((r, i) =>
    r.amount !== (baselineSchedule[i]?.amount ?? 0) ||
    (r.reason || null) !== (baselineSchedule[i]?.reason || null))

  function updateRow(i, patch) {
    setSchedule(s => s.map((r, j) => j === i ? { ...r, ...patch } : r))
  }
  function addYear() {
    setSchedule(s => {
      const last = s[s.length - 1]
      return [...s, { age: (last?.age || currentAge) + 1, amount: last?.amount || 0, reason: null }]
    })
  }
  function removeYear(i) {
    setSchedule(s => s.filter((_, j) => j !== i))
  }
  function applyPreset(id) {
    const p = presets.find(x => x.id === id)
    if (p) setSchedule(p.make())
  }
  function handleCommit() {
    if (!isDirty) return
    onCommit?.(schedule)
  }

  // Data-completeness check per FP-4 — flag explicit gaps rather than
  // presenting confident numbers on incomplete data
  const hasNominationData = (a.sipp?.pensions || []).every(p => p.nominationDate)
  const hasGrowth          = !!a.sipp?.growth

  return (
    <OverlayShell title="Pension" subtitle={`${fmt(sippTot)} · ${(a.sipp?.pensions || []).length} schemes`}
      onBack={onBack} onHome={onHome}>
      <div style={{ padding: '16px 16px 40px' }}>

        {/* ─── Pension summary ─────────────────────────────────────── */}
        <div style={{
          background: 'var(--c-surface)', borderRadius: 16,
          border: '1px solid var(--c-sep)', padding: '14px 16px', marginBottom: 12,
        }}>
          <div style={{
            fontSize: 11, fontWeight: 700, color: 'var(--c-text3)',
            textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6,
          }}>Pension total</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: 'var(--c-text)',
            letterSpacing: -1, marginBottom: 8 }}>{fmt(sippTot)}</div>
          <div style={{ fontSize: 13, color: 'var(--c-text2)', lineHeight: 1.5 }}>
            Currently {entity.drawdown > 0
              ? <>drawing <strong>{fmt(entity.drawdown)}/yr</strong>.</>
              : <>not in drawdown. From <strong>6 April 2027</strong> the full value enters your estate for IHT.</>}
            {coiCurrent > 0 && (
              <>  Cost of inaction today: <strong style={{ color: '#FF6B6B' }}>{fmt(coiCurrent)}</strong>.</>
            )}
          </div>
        </div>

        {/* ─── Pension schemes list with nomination status ─────────── */}
        <SectionTitle>Schemes & nominations</SectionTitle>
        <PensionList entity={entity} personaId={personaId} onCommitEvent={onCommit} />

        {/* ─── Drawdown schedule editor ────────────────────────────── */}
        <SectionTitle>Drawdown schedule</SectionTitle>

        <div style={{ fontSize: 13, color: 'var(--c-text2)', lineHeight: 1.6, marginBottom: 10 }}>
          Real life is rarely a flat number every year. Set what you actually
          expect to draw per year — including one-off events.
        </div>

        {/* Preset chips */}
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 14 }}>
          {presets.map(p => (
            <button key={p.id} onClick={() => applyPreset(p.id)} style={{
              padding: '6px 12px', borderRadius: 100, fontSize: 12,
              fontWeight: 600, background: 'var(--c-surface)',
              color: 'var(--c-text2)', border: '1px solid var(--c-sep)',
              cursor: 'pointer',
            }}>{p.label}</button>
          ))}
        </div>

        {/* Schedule rows */}
        <div style={{
          background: 'var(--c-surface)', border: '1px solid var(--c-sep)',
          borderRadius: 16, overflow: 'hidden', marginBottom: 12,
        }}>
          {schedule.map((row, i) => (
            <ScheduleRow
              key={i}
              row={row}
              onAmount={v => updateRow(i, { amount: v })}
              onReason={v => updateRow(i, { reason: v })}
              onRemove={schedule.length > 1 ? () => removeYear(i) : null}
              isLast={i === schedule.length - 1}
              warnAboveGuard={guard > 0 && row.amount > guard * 2}
            />
          ))}
          <button onClick={addYear} style={{
            width: '100%', padding: '12px 0', fontSize: 13, fontWeight: 600,
            color: '#4D8EFF', background: 'rgba(77,142,255,0.08)',
            border: 'none', borderTop: '1px solid var(--c-sep)',
            cursor: 'pointer',
          }}>+ Add next year</button>
        </div>

        {/* ─── Live engine outputs ─────────────────────────────────── */}
        <SectionTitle>Projected impact</SectionTitle>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr',
          gap: 10, marginBottom: 12 }}>
          <MetricTile
            label={`SIPP after ${yearsAhead} yrs`}
            value={hasGrowth ? fmt(endValue) : '—'}
            missing={!hasGrowth && 'Needs growth rate'}
            colour="var(--c-text)"
          />
          <MetricTile
            label="Total drawn"
            value={fmt(schedule.reduce((s, r) => s + (r.amount || 0), 0))}
            colour="#00E5A8"
          />
          <MetricTile
            label="IHT today (this plan)"
            value={hasNominationData ? fmt(ihtWithSchedule) : 'Incomplete'}
            missing={!hasNominationData && 'Some nominations missing'}
            colour="#FF6B6B"
          />
          <MetricTile
            label="IHT saved vs no action"
            value={ihtDelta > 0 ? fmt(ihtDelta) : '—'}
            colour="#00E5A8"
          />
        </div>

        {/* ─── Projection mini-chart ──────────────────────────────── */}
        <ProjectionChart series={series} sippStart={sippTot} />

        {/* ─── Commit bar ─────────────────────────────────────────── */}
        <div style={{ marginTop: 16, display: 'flex', gap: 10 }}>
          <button
            onClick={onBack}
            style={{
              flex: 1, padding: '13px 0', fontSize: 14, fontWeight: 600,
              background: 'var(--c-surface2)', color: 'var(--c-text2)',
              border: '1px solid var(--c-sep)', borderRadius: 100,
              cursor: 'pointer',
            }}>Cancel</button>
          <button
            onClick={handleCommit}
            disabled={!isDirty}
            style={{
              flex: 2, padding: '13px 0', fontSize: 14, fontWeight: 700,
              background: isDirty ? '#00E5A8' : 'var(--c-surface2)',
              color: isDirty ? '#0B1F3A' : 'var(--c-text3)',
              border: 'none', borderRadius: 100,
              cursor: isDirty ? 'pointer' : 'not-allowed',
            }}>
            {isDirty ? 'Commit schedule' : 'No changes'}
          </button>
        </div>

        <div style={{ fontSize: 11, color: 'var(--c-text3)', marginTop: 16,
          lineHeight: 1.5 }}>
          Simulated values use {((a.sipp?.growth || 0.05) * 100).toFixed(1)}% growth assumption.
          Not regulated financial advice. Verify with a qualified adviser.
        </div>
      </div>
    </OverlayShell>
  )
}

// ─── Small helpers used by PensionDrillDown ──────────────────────────────
function SectionTitle({ children }) {
  return (
    <div style={{
      fontSize: 11, fontWeight: 700, color: 'var(--c-text3)',
      textTransform: 'uppercase', letterSpacing: 0.8,
      margin: '18px 0 8px',
    }}>{children}</div>
  )
}

function MetricTile({ label, value, missing, colour }) {
  return (
    <div style={{
      background: 'var(--c-surface2)', borderRadius: 12, padding: '10px 12px',
    }}>
      <div style={{
        fontSize: 11, color: 'var(--c-text3)', textTransform: 'uppercase',
        letterSpacing: 0.5, marginBottom: 4,
      }}>{label}</div>
      <div style={{
        fontSize: 16, fontWeight: 700,
        color: missing ? 'var(--c-text3)' : colour,
        fontStyle: missing ? 'italic' : 'normal',
      }}>{value}</div>
      {missing && (
        <div style={{ fontSize: 10, color: 'var(--c-text3)', marginTop: 2 }}>
          {missing}
        </div>
      )}
    </div>
  )
}

function ScheduleRow({ row, onAmount, onReason, onRemove, isLast, warnAboveGuard }) {
  return (
    <div style={{
      padding: '10px 14px',
      borderBottom: isLast ? 'none' : '1px solid var(--c-sep)',
      display: 'flex', flexDirection: 'column', gap: 8,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{
          width: 48, flexShrink: 0,
          fontSize: 11, fontWeight: 700, color: 'var(--c-text3)',
          textTransform: 'uppercase', letterSpacing: 0.8,
        }}>Age {row.age}</div>
        <div style={{ flex: 1, position: 'relative' }}>
          <span style={{
            position: 'absolute', left: 12, top: '50%',
            transform: 'translateY(-50%)', color: 'var(--c-text3)', fontSize: 14,
          }}>£</span>
          <input
            type="number" min={0} step={500}
            value={row.amount || 0}
            onChange={e => onAmount(Number(e.target.value) || 0)}
            style={{
              width: '100%', padding: '8px 10px 8px 22px',
              fontSize: 14, fontWeight: 600, color: 'var(--c-text)',
              background: 'var(--c-surface2)', border: `1px solid ${warnAboveGuard ? 'rgba(255,179,71,0.5)' : 'var(--c-sep)'}`,
              borderRadius: 8, outline: 'none',
            }}
          />
        </div>
        {onRemove && (
          <button onClick={onRemove} aria-label="Remove year" style={{
            width: 32, height: 32, borderRadius: 8, flexShrink: 0,
            background: 'transparent', border: '1px solid var(--c-sep)',
            color: 'var(--c-text3)', fontSize: 16, cursor: 'pointer',
          }}>×</button>
        )}
      </div>
      <input
        type="text"
        placeholder="Reason (optional) — e.g. wedding, holiday, one-off"
        value={row.reason || ''}
        onChange={e => onReason(e.target.value || null)}
        style={{
          width: '100%', padding: '6px 10px', fontSize: 12,
          color: 'var(--c-text2)', background: 'transparent',
          border: '1px solid var(--c-sep)', borderRadius: 8, outline: 'none',
        }}
      />
      {warnAboveGuard && (
        <div style={{ fontSize: 11, color: '#FFB347', fontStyle: 'italic' }}>
          ⚠ Above 2× your safe withdrawal rate — depletes capital faster
        </div>
      )}
    </div>
  )
}

function ProjectionChart({ series, sippStart }) {
  if (!series || series.length === 0) return null
  const W = 320, H = 80, pL = 4, pR = 4, pT = 6, pB = 16
  const pw = W - pL - pR, ph = H - pT - pB
  const maxV = Math.max(sippStart, ...series.map(s => s.value))
  const pts = [
    { age: (series[0].age || 0) - 1, value: sippStart },
    ...series,
  ].map((s, i, arr) => ({
    x: pL + (i / (arr.length - 1)) * pw,
    y: pT + ph - (s.value / maxV) * ph,
    age: s.age,
    value: s.value,
  }))
  const path = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ')
  return (
    <div style={{
      background: 'var(--c-surface)', border: '1px solid var(--c-sep)',
      borderRadius: 16, padding: '10px 12px', marginTop: 8,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
        <div style={{
          fontSize: 11, fontWeight: 700, color: 'var(--c-text3)',
          textTransform: 'uppercase', letterSpacing: 0.8,
        }}>SIPP value — projected</div>
        <div style={{ fontSize: 11, color: 'var(--c-text3)' }}>
          {fmt(sippStart)} → {fmt(pts[pts.length - 1].value)}
        </div>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" style={{ display: 'block' }}>
        <path d={`${path} L${pts[pts.length-1].x.toFixed(1)},${(pT+ph).toFixed(1)} L${pts[0].x.toFixed(1)},${(pT+ph).toFixed(1)} Z`}
          fill="rgba(77,142,255,0.12)" />
        <path d={path} fill="none" stroke="#4D8EFF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        {pts.map((p, i) => (
          <circle key={i} cx={p.x.toFixed(1)} cy={p.y.toFixed(1)} r="3"
            fill="#4D8EFF" stroke="rgba(8,14,26,0.8)" strokeWidth="1.5" />
        ))}
        {pts.filter((_, i) => i % 2 === 0).map((p, i) => (
          <text key={`l${i}`} x={p.x.toFixed(0)} y={H - 2}
            fontSize="10" fill="#4A5878" textAnchor="middle"
            fontFamily="DM Sans,sans-serif">
            {p.age || 'now'}
          </text>
        ))}
      </svg>
    </div>
  )
}

// ─── Pensions list with nomination status + "Mark reviewed" action ───────
function PensionList({ entity, personaId, onCommitEvent }) {
  const rows = nominationStatus(entity)
  if (rows.length === 0) return null

  return (
    <div style={{
      background: 'var(--c-surface)', border: '1px solid var(--c-sep)',
      borderRadius: 16, overflow: 'hidden',
    }}>
      {rows.map((p, i) => {
        const statusColour = p.status === 'stale' || p.status === 'missing' ? '#FF9500'
                           : p.status === 'aging' ? '#FFB347'
                           : '#00E5A8'
        const statusLabel  = p.status === 'stale'   ? `Stale (${p.ageYears}y)`
                           : p.status === 'missing' ? 'No nomination'
                           : p.status === 'aging'   ? `Aging (${p.ageYears}y)`
                           : `Current (${p.ageYears}y)`
        return (
          <div key={i} style={{
            padding: '12px 14px',
            borderBottom: i < rows.length - 1 ? '1px solid var(--c-sep)' : 'none',
            display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--c-text)',
                marginBottom: 2 }}>{p.name}</div>
              <div style={{ fontSize: 11, color: 'var(--c-text3)' }}>
                {fmt(p.value)} · {(p.charge * 100).toFixed(2)}% charge ·&nbsp;
                <span style={{ color: statusColour, fontWeight: 600 }}>{statusLabel}</span>
              </div>
            </div>
            {(p.status === 'stale' || p.status === 'missing') && (
              <button
                onClick={() => onCommitEvent?.({
                  type: EV.NOMINATION_REVIEWED,
                  payload: { pensionName: p.name, reviewedDate: new Date().toISOString().slice(0, 10) },
                })}
                style={{
                  padding: '6px 10px', borderRadius: 100, fontSize: 11, fontWeight: 600,
                  background: 'rgba(255,149,0,0.1)', color: '#FF9500',
                  border: '1px solid rgba(255,149,0,0.35)',
                  cursor: 'pointer', flexShrink: 0, whiteSpace: 'nowrap',
                }}>Mark reviewed</button>
            )}
          </div>
        )
      })}
    </div>
  )
}

// ─── Income section ───────────────────────────────────────────────────────
function IncomeSection({ entity }) {
  const inc = entity.income || {}
  const sources = [
    { label:'Employment income',  val: inc.employment  || 0, active: (inc.employment||0)  > 0 },
    { label:'Dividends',          val: inc.dividends   || 0, active: (inc.dividends||0)   > 0 },
    { label:'Rental income',      val: inc.rentalIncome|| 0, active: (inc.rentalIncome||0) > 0 },
    { label:'State Pension',      val: inc.statePension?.annual || 0,
      active: !!(inc.statePension?.annual), note:`from age ${inc.statePension?.startAge||67}` },
    { label:'Drawdown',           val: entity.drawdown || 0, active: (entity.drawdown||0) > 0 },
    { label:'Overseas income',    val: inc.overseasIncome || 0, active: (inc.overseasIncome||0) > 0 },
  ].filter(s => s.active)

  if (!sources.length) return null
  const total = sources.reduce((s, x) => s + x.val, 0)

  return (
    <div className="card">
      <div className="card-title">Income Sources — {fmt(total)}/yr</div>
      {sources.map((s, i) => (
        <div key={s.label} className="row" style={{
          paddingTop: i > 0 ? 10 : 0, marginTop: i > 0 ? 10 : 0 }}>
          <div>
            <div style={{ fontSize:13, color:'var(--c-text)' }}>{s.label}</div>
            {s.note && <div style={{ fontSize:11, color:'var(--c-text3)', marginTop:1 }}>{s.note}</div>}
          </div>
          <div style={{ fontSize:14, fontWeight:700, color:'var(--c-acc)' }}>
            {fmt(s.val)}/yr
          </div>
        </div>
      ))}
    </div>
  )
}

function CashflowStrip({ entity }) {
  const gr       = guardrail(entity)
  const dd       = entity.drawdown || 0
  const monthly  = (entity.targetIncome || 50000) / 12
  const cashMos  = (entity.assets?.cash?.own || entity.assets?.cash?.total || 0) / monthly

  return (
    <div className="card">
      <div className="card-title">Cashflow Health</div>
      {[
        { label:'Safe withdrawal ceiling', val:fmt(gr) + '/yr', note:'4% of investable assets' },
        { label:'Current drawdown',        val: dd > 0 ? fmt(dd)+'/yr' : 'Not started',
          note: dd > 0 && dd <= gr ? 'Within guardrail'
              : dd > gr ? '⚠ Exceeds guardrail'
              : 'Pension accessible from age 55+' },
        { label:'Cash runway',             val:`${Math.round(cashMos)} months`, note:'At current income target' },
      ].map((r, i) => (
        <div key={r.label} className="row" style={{
          paddingTop: i > 0 ? 10 : 0, marginTop: i > 0 ? 10 : 0 }}>
          <div>
            <div style={{ fontSize:13, color:'var(--c-text)' }}>{r.label}</div>
            <div style={{ fontSize:11, color:'var(--c-text3)', marginTop:1 }}>{r.note}</div>
          </div>
          <div style={{ fontSize:14, fontWeight:700, color:'var(--c-text)' }}>
            {r.val}
          </div>
        </div>
      ))}
    </div>
  )
}

// ─── Main export ──────────────────────────────────────────────────────────
export default function MyMoney({ entity, personaId, onCommit, onHome }) {
  const [activeSheet,     setActiveSheet]     = useState(null)
  const [drillPension,    setDrillPension]    = useState(false)
  const { cats, liabCat, totalAssets, totalLiab, nw } = useMemo(
    () => buildCategories(entity),
    [entity]
  )

  function handleCatTap(cat) {
    if (cat.drillType === 'pension') {
      setDrillPension(true)
    } else {
      setActiveSheet(cat)
    }
  }

  // Commit handlers passed into PensionDrillDown
  function handleCommitSchedule(schedule) {
    onCommit?.({
      type: EV.DRAWDOWN_SCHEDULE_SET,
      payload: { schedule },
    })
    setDrillPension(false)
  }
  function handleCommitEvent(event) {
    onCommit?.(event)
  }

  return (
    <div className="screen">
      <div style={{ textAlign:'right', fontSize:11, color:'var(--c-text3)',
        padding:'6px 0 4px' }}>
        {BRAND.rulesVersion} · {BRAND.dataDate}
      </div>

      {/* Net Worth hero */}
      <div className="card" style={{ marginBottom:12, textAlign:'center' }}>
        <div style={{ fontSize:11, fontWeight:700, color:'var(--c-text3)',
          textTransform:'uppercase', letterSpacing:1.1, marginBottom:6 }}>
          {BRAND.netWorth}
        </div>
        <div style={{ fontSize:40, fontWeight:900, color:'var(--c-text)',
          letterSpacing:-2, marginBottom:4 }}>
          {fmt(nw)}
        </div>
        <div style={{ display:'flex', justifyContent:'center', gap:20 }}>
          <div style={{ textAlign:'center' }}>
            <div style={{ fontSize:13, color:'var(--c-text3)', marginBottom:2 }}>Assets</div>
            <div style={{ fontSize:15, fontWeight:700, color:'#00E5A8' }}>{fmt(totalAssets)}</div>
          </div>
          <div style={{ width:1, background:'var(--c-sep)' }} />
          <div style={{ textAlign:'center' }}>
            <div style={{ fontSize:13, color:'var(--c-text3)', marginBottom:2 }}>Liabilities</div>
            <div style={{ fontSize:15, fontWeight:700, color:'#FF6B6B' }}>−{fmt(totalLiab)}</div>
          </div>
        </div>
      </div>

      {/* Proportional bar */}
      <div className="card">
        <PropBar cats={cats} total={totalAssets} />

        <div style={{ display:'flex', flexWrap:'wrap', gap:'6px 12px',
          marginBottom:16 }}>
          {cats.map(c => (
            <div key={c.id} style={{ display:'flex', alignItems:'center', gap:5 }}>
              <div style={{ width:8, height:8, borderRadius:'50%',
                background:c.colour }} />
              <span style={{ fontSize:11, color:'var(--c-text3)' }}>{c.label}</span>
            </div>
          ))}
        </div>

        <div className="card-title">Assets — tap for detail</div>
        {cats.map(c => (
          <CatRow key={c.id} cat={c} total={totalAssets} onTap={handleCatTap} />
        ))}

        {totalLiab > 0 && (
          <>
            <div className="card-title" style={{ marginTop:16 }}>Liabilities</div>
            <CatRow cat={liabCat} total={totalAssets} onTap={handleCatTap} />
          </>
        )}
      </div>

      <IncomeSection entity={entity} />
      <CashflowStrip entity={entity} />

      {entity.assets?.indianAssets && (
        <div className="card">
          <div className="card-title">Indian Assets (NRI)</div>
          <div style={{ background:'rgba(255,179,71,.07)',
            border:'1px solid rgba(255,179,71,.25)', borderRadius:10,
            padding:'8px 12px', marginBottom:12, fontSize:13,
            color:'#FFB347' }}>
            India bundle loading — DTAA computations pending
          </div>
          {[
            { label:'NRE Account',    val: fmt(entity.assets.indianAssets.nreAccount?.value_gbp || 0) },
            { label:'NRO Account',    val: fmt(entity.assets.indianAssets.nroAccount?.value_gbp || 0) },
            { label:'EPF (approx)',   val: fmt(entity.assets.indianAssets.epf?.value_gbp_approx || 0) },
            { label:'Mutual Funds',   val: fmt(entity.assets.indianAssets.mutualFunds?.value_gbp_approx || 0) },
          ].map((r, i) => (
            <div key={r.label} className="row" style={{
              paddingTop: i > 0 ? 10 : 0, marginTop: i > 0 ? 10 : 0 }}>
              <div style={{ fontSize:13, color:'var(--c-text)' }}>{r.label}</div>
              <div style={{ fontSize:13, fontWeight:600, color:'var(--c-text)' }}>{r.val}</div>
            </div>
          ))}
        </div>
      )}

      <p className="disclaimer">{BRAND.disclaimer}<br />{BRAND.rulesVersion} · {BRAND.dataDate}</p>

      {/* Non-pension cat drill → bottom sheet */}
      {activeSheet && (
        <LineItemSheet cat={activeSheet} onClose={() => setActiveSheet(null)} />
      )}

      {/* Pension cat drill → full-screen drill-down */}
      {drillPension && (
        <PensionDrillDown
          entity={entity}
          personaId={personaId}
          onBack={() => setDrillPension(false)}
          onHome={onHome}
          onCommit={(eventOrSchedule) => {
            // Two call shapes:
            //   · Event object   → forwarded verbatim
            //   · Schedule array → wrap as DRAWDOWN_SCHEDULE_SET
            if (Array.isArray(eventOrSchedule)) {
              handleCommitSchedule(eventOrSchedule)
            } else if (eventOrSchedule && eventOrSchedule.type) {
              handleCommitEvent(eventOrSchedule)
            }
          }}
        />
      )}
    </div>
  )
}
