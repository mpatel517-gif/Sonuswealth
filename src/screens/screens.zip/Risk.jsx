import { useState, useEffect } from 'react'
import { fmt, netWorth, calcFQ, fqBand } from '../engine/fq-calculator.js'
import { calcRisk, riskBand, financialProfile } from '../engine/fq-calculator.js'
import { BRAND } from '../config/brand.js'

// ── Risk dimension config ─────────────────────────────────────────────────
const DIMS = [
  { key:'incomeRes',        label:'Income Resilience',     max:20, icon:'◈' },
  { key:'liquidity',        label:'Liquidity Buffer',      max:18, icon:'◉' },
  { key:'protCov',          label:'Protection Coverage',   max:18, icon:'◐' },
  { key:'debtVuln',         label:'Debt Vulnerability',    max:15, icon:'⚖' },
  { key:'concRisk',         label:'Concentration Risk',    max:12, icon:'◎' },
  { key:'depExp',           label:'Dependency Exposure',   max:10, icon:'◑' },
  { key:'behaviouralTrack', label:'Behavioural Track',     max:7,  icon:'◷' },
]
const RISK_DIM_DESCRIPTIONS = {
  incomeRes:        'How resilient your income is — number of sources, stability, and what happens if the primary source stops.',
  liquidity:        'Whether you hold enough accessible cash to absorb a shock without selling investments.',
  protCov:          'How well protected you are against loss of income, death, or serious illness.',
  debtVuln:         'Whether your debt level amplifies your financial risks — leverage, debt service, and rate exposure.',
  concRisk:         'Whether your wealth and income are over-concentrated in a single asset, employer, or asset class.',
  depExp:           'Whether people who depend on you would be provided for — will, nominations, LPA, guardian.',
  behaviouralTrack: 'Your demonstrated financial behaviour on the platform over time. Starts at zero — earns through action.',
}

// ── Dim bar colour by % of max ────────────────────────────────────────────
function dimColor(score, max) {
  const pct = score / max
  if (pct >= 0.80) return '#00E5A8'
  if (pct >= 0.60) return '#4D8EFF'
  if (pct >= 0.40) return '#FFB347'
  if (pct >= 0.20) return '#FF6B6B'
  return '#FF3B30'
}

// ── Animated ring gauge ───────────────────────────────────────────────────
function RiskRing({ score, band }) {
  const R = 80, CIRC = 2 * Math.PI * R
  const [fill, setFill] = useState(0)
  useEffect(() => {
    const t = setTimeout(() => setFill(score), 80)
    return () => clearTimeout(t)
  }, [score])

  return (
    <svg viewBox="0 0 200 200" width="200" height="200" style={{ overflow:'visible' }}>
      {/* Subtle sector rings */}
      {[0.2,0.4,0.6,0.8].map(r => (
        <circle key={r} cx={100} cy={100} r={r*(R-4)} fill="none"
          stroke="rgba(255,255,255,0.04)" strokeWidth="0.5" />
      ))}
      {/* Background ring */}
      <circle cx={100} cy={100} r={R} fill="none"
        stroke="rgba(255,255,255,0.08)" strokeWidth="14" />
      {/* Score fill */}
      <circle cx={100} cy={100} r={R} fill="none"
        stroke={band.colour} strokeWidth="14" strokeLinecap="round"
        strokeDasharray={`${(fill/100)*CIRC} ${CIRC}`}
        strokeDashoffset={CIRC * 0.25}
        style={{ transition:'stroke-dasharray 1.2s cubic-bezier(0.4,0,0.2,1)' }}
      />
      {/* Score number */}
      <text x={100} y={96} textAnchor="middle"
        fontSize="38" fontWeight="900" fill="var(--c-text)"
        fontFamily="DM Sans, sans-serif" letterSpacing="-2">
        {score}
      </text>
      <text x={100} y={116} textAnchor="middle"
        fontSize="11" fontWeight="700" fill={band.colour}
        fontFamily="DM Sans, sans-serif">
        {band.name}
      </text>
      <text x={100} y={132} textAnchor="middle"
        fontSize="11" fill="var(--c-text3)"
        fontFamily="DM Sans, sans-serif">
        Risk Score
      </text>
    </svg>
  )
}

// ── Confidence badge ──────────────────────────────────────────────────────
function ConfBadge({ level }) {
  const cfg = level === 'high'   ? { label:'High accuracy',   colour:'#00E5A8', bg:'rgba(0,229,168,.12)',  range:'' }
             : level === 'medium' ? { label:'Medium accuracy', colour:'#4D8EFF', bg:'rgba(77,142,255,.12)', range:'±8 pts' }
             :                      { label:'Low accuracy',    colour:'#FFB347', bg:'rgba(255,179,71,.12)', range:'±15 pts' }
  return (
    <div style={{ display:'flex', alignItems:'center', gap:6 }}>
      <div style={{ fontSize:11, fontWeight:700, color:cfg.colour,
        background:cfg.bg, padding:'3px 10px', borderRadius:100,
        border:`1px solid ${cfg.colour}33` }}>
        {cfg.label}
      </div>
      {cfg.range && (
        <div style={{ fontSize:11, color:'var(--c-text3)' }}>{cfg.range}</div>
      )}
    </div>
  )
}

// ── Financial profile cell ────────────────────────────────────────────────
function ProfileCell({ profile }) {
  if (!profile) return null
  return (
    <div className="card" style={{ marginBottom:12, textAlign:'center' }}>
      <div style={{ fontSize:11, fontWeight:700, color:'var(--c-text3)',
        textTransform:'uppercase', letterSpacing:.8, marginBottom:6 }}>
        {BRAND.financialProfile}
      </div>
      <div style={{ fontSize:17, fontWeight:800, color:'var(--c-text)',
        marginBottom:6 }}>
        {profile.profileName}
      </div>
      <div style={{ fontSize:13, color:'var(--c-text2)', lineHeight:1.55 }}>
        {profile.profileImplication}
      </div>
    </div>
  )
}

// ── Dimension row ─────────────────────────────────────────────────────────
function DimRow({ dimCfg, score, onTap }) {
  const pct   = Math.round((score / dimCfg.max) * 100)
  const color = dimColor(score, dimCfg.max)
  return (
    <div onClick={() => onTap(dimCfg)} style={{
      display:'flex', alignItems:'center', gap:10,
      padding:'10px 0', borderBottom:'1px solid var(--c-sep)',
      cursor:'pointer',
    }}>
      <div style={{ width:7, height:7, borderRadius:'50%',
        background:color, flexShrink:0 }} />
      <div style={{ fontSize:13, color:'var(--c-text2)', width:140, flexShrink:0 }}>
        {dimCfg.label}
      </div>
      <div className="risk-bar-track">
        <div className="risk-bar-fill" style={{ width:`${pct}%`, background:color }} />
      </div>
      <div style={{ fontSize:13, fontWeight:700, color, width:36,
        textAlign:'right', flexShrink:0 }}>
        {score}/{dimCfg.max}
      </div>
      <div style={{ fontSize:14, color:'var(--c-text3)', flexShrink:0 }}>›</div>
    </div>
  )
}

// ── Dimension detail sheet ────────────────────────────────────────────────
function DimSheet({ dimCfg, score, onClose }) {
  if (!dimCfg) return null
  const pct   = Math.round((score / dimCfg.max) * 100)
  const color = dimColor(score, dimCfg.max)
  return (
    <div className="sheet-overlay">
      <div className="sheet-backdrop" onClick={onClose} />
      <div className="sheet-panel">
        <div className="sheet-handle" />
        <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:16 }}>
          <div style={{ width:44, height:44, borderRadius:12,
            background:`${color}22`, display:'flex', alignItems:'center',
            justifyContent:'center', fontSize:20 }}>
            {dimCfg.icon}
          </div>
          <div>
            <div style={{ fontSize:17, fontWeight:800, color:'var(--c-text)' }}>
              {dimCfg.label}
            </div>
            <div style={{ fontSize:13, color, fontWeight:600, marginTop:2 }}>
              {score}/{dimCfg.max} · {pct}% of maximum
            </div>
          </div>
        </div>
        <div style={{ fontSize:14, color:'var(--c-text2)', lineHeight:1.7,
          marginBottom:16 }}>
          {RISK_DIM_DESCRIPTIONS[dimCfg.key]}
        </div>
        {dimCfg.key === 'behaviouralTrack' && (
          <div style={{ background:'rgba(255,179,71,.08)',
            border:'1px solid rgba(255,179,71,.25)', borderRadius:12,
            padding:12, marginBottom:16 }}>
            <div style={{ fontSize:13, color:'#FFB347', fontWeight:700,
              marginBottom:4 }}>
              How to earn points
            </div>
            <div style={{ fontSize:13, color:'var(--c-text2)', lineHeight:1.6 }}>
              Complete APQ actions, update profile after life events, respond to deadline prompts, upload documents when asked. Points accumulate over time — not immediately.
            </div>
          </div>
        )}
        <button onClick={onClose} style={{ width:'100%',
          background:'var(--c-acc2)', color:'#fff', border:'none',
          borderRadius:100, padding:'13px 0', fontSize:14,
          fontWeight:700, cursor:'pointer' }}>
          Got it
        </button>
      </div>
    </div>
  )
}

// ── Shock scenario computation ────────────────────────────────────────────
function computeShocks(entity) {
  const fq   = calcFQ(entity)
  const risk = calcRisk(entity)
  const nw   = netWorth(entity)
  const a    = entity.assets || {}

  const shocks = []

  // Shock 1: Market fall 30%
  const portfolioVal = (a.portfolio?.value || 0) + (a.sipp?.total || 0) * 0.6
  const nwDrop30 = portfolioVal * 0.30
  shocks.push({
    id:'market', label:'Market fall 30%', icon:'📉',
    colour:'#FF6B6B',
    nwDelta: -Math.round(nwDrop30),
    fqDelta: -8,
    riskDelta: -6,
    action:'Diversify holdings. Reduce single-asset concentration.',
    applicable: portfolioVal > 10000,
  })

  // Shock 2: Job loss / income stop
  const hasIncome = (entity.income?.employment || 0) > 0
  shocks.push({
    id:'jobloss', label:'Loss of income', icon:'💼',
    colour:'#FF9500',
    nwDelta: -Math.round((entity.targetIncome || 50000) * 0.5),
    fqDelta: -10,
    riskDelta: -14,
    action:'Income protection covers 60–70% of gross income. Emergency fund is your buffer.',
    applicable: hasIncome,
  })

  // Shock 3: Rate rise 2%
  const mortgage = entity.liabilities?.mortgage
  const hasVariable = mortgage?.rateType === 'variable' && mortgage?.outstanding > 0
  const extraMonthly = hasVariable ? Math.round(mortgage.outstanding * 0.02 / 12) : 0
  shocks.push({
    id:'rate', label:'Interest rate rise 2%', icon:'📈',
    colour:'#FFB347',
    nwDelta: 0,
    fqDelta: -3,
    riskDelta: hasVariable ? -8 : -2,
    action: hasVariable
      ? `Monthly mortgage cost rises by ${fmt(extraMonthly)}. Fix rate when term ends.`
      : 'Fixed rate mortgage protects you from rate rises for now.',
    applicable: (mortgage?.outstanding || 0) > 0,
  })

  // Shock 4: Serious illness (6 months)
  shocks.push({
    id:'illness', label:'Serious illness — 6 months', icon:'🏥',
    colour:'#FF6B6B',
    nwDelta: -Math.round((entity.targetIncome || 50000) * 0.5),
    fqDelta: -7,
    riskDelta: -12,
    action:'Income protection and critical illness cover are the two products that address this directly.',
    applicable: true,
  })

  // Shock 5: Estate — death of primary earner
  shocks.push({
    id:'death', label:'Death of primary earner', icon:'⚖',
    colour:'#FF3B30',
    nwDelta: 0,
    fqDelta: 0,
    riskDelta: -20,
    action:'Life insurance in trust, current pension nominations, and a valid will are the three instruments.',
    applicable: true,
  })

  return shocks.filter(s => s.applicable)
}

// ── Shock card ────────────────────────────────────────────────────────────
function ShockCard({ shock, fqScore, riskScore, nw }) {
  const [open, setOpen] = useState(false)
  return (
    <div onClick={() => setOpen(!open)} style={{
      background:'var(--c-surface)', border:'1px solid var(--c-sep)',
      borderLeft:`4px solid ${shock.colour}`, borderRadius:'0 14px 14px 0',
      padding:'12px 14px', marginBottom:8, cursor:'pointer',
    }}>
      <div style={{ display:'flex', alignItems:'center',
        justifyContent:'space-between' }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <span style={{ fontSize:20 }}>{shock.icon}</span>
          <div>
            <div style={{ fontSize:13, fontWeight:700, color:'var(--c-text)' }}>
              {shock.label}
            </div>
            <div style={{ fontSize:11, color:shock.colour, marginTop:1 }}>
              Risk Score {riskScore + shock.riskDelta < 0 ? 0 : riskScore + shock.riskDelta}
              {' '}· Finio Score {fqScore + shock.fqDelta < 0 ? 0 : fqScore + shock.fqDelta}
            </div>
          </div>
        </div>
        <span style={{ color:'var(--c-text3)', fontSize:14,
          transform: open ? 'rotate(90deg)' : 'none',
          transition:'transform .2s' }}>›</span>
      </div>
      {open && (
        <div style={{ marginTop:12, paddingTop:12,
          borderTop:'1px solid var(--c-sep)' }}>
          <div style={{ display:'flex', gap:16, marginBottom:10 }}>
            {[
              { label:'Net Worth', before:fmt(nw), after:fmt(nw + shock.nwDelta) },
              { label:'Finio',     before:fqScore, after:Math.max(0,fqScore + shock.fqDelta) },
              { label:'Risk',      before:riskScore, after:Math.max(0,riskScore + shock.riskDelta) },
            ].map(m => (
              <div key={m.label} style={{ flex:1 }}>
                <div style={{ fontSize:11, color:'var(--c-text3)',
                  textTransform:'uppercase', letterSpacing:.5,
                  marginBottom:3 }}>{m.label}</div>
                <div style={{ fontSize:11, color:'var(--c-text3)',
                  marginBottom:1 }}>Now: {m.before}</div>
                <div style={{ fontSize:13, fontWeight:700,
                  color:shock.colour }}>If: {m.after}</div>
              </div>
            ))}
          </div>
          <div style={{ background:`${shock.colour}12`,
            border:`1px solid ${shock.colour}33`,
            borderRadius:10, padding:'8px 12px',
            fontSize:13, color:'var(--c-text2)', lineHeight:1.55 }}>
            {shock.action}
          </div>
        </div>
      )}
    </div>
  )
}

// ── Main export ───────────────────────────────────────────────────────────
export default function Risk({ entity }) {
  const [activeDim, setActiveDim] = useState(null)

  const risk    = calcRisk(entity)
  const fq      = calcFQ(entity)
  const nw      = netWorth(entity)
  const shocks  = computeShocks(entity)

  let profile = null
  try { profile = financialProfile(entity) } catch {}

  return (
    <div className="screen">
      <div style={{ textAlign:'right', fontSize:11, color:'var(--c-text3)',
        padding:'6px 0 4px' }}>
        {BRAND.rulesVersion} · {BRAND.dataDate}
      </div>

      {/* ── Ring gauge centred ──────────────────────────────────────────── */}
      <div style={{ display:'flex', flexDirection:'column',
        alignItems:'center', marginBottom:8 }}>
        <RiskRing score={risk.total} band={risk.band} />
        <ConfBadge level={risk.confidenceLevel || 'low'} />
      </div>

      {/* ── Financial profile ──────────────────────────────────────────── */}
      <ProfileCell profile={profile} />

      {/* ── Seven dimensions ───────────────────────────────────────────── */}
      <div className="card">
        <div className="card-title">Resilience Dimensions</div>
        {DIMS.map(d => (
          <DimRow
            key={d.key}
            dimCfg={d}
            score={risk.dims[d.key] || 0}
            onTap={setActiveDim}
          />
        ))}
      </div>

      {/* ── Protection coverage quick view ─────────────────────────────── */}
      <div className="card">
        <div className="card-title">Protection Coverage</div>
        {[
          { label:'Income protection',  has: entity.assets?.protection?.incomeProtection?.exists },
          { label:'Life insurance',     has: entity.assets?.protection?.lifeInsurance?.exists,
            note: entity.assets?.protection?.lifeInsurance?.inTrust ? 'In trust ✓' : 'Not in trust' },
          { label:'Critical illness',   has: entity.assets?.protection?.criticalIllness?.exists },
          { label:'Will — current',     has: entity.willStatus === 'current' },
          { label:'LPA in place',       has: entity.lpaStatus === 'both',
            note: entity.lpaStatus === 'financial_only' ? 'Financial only' : null },
        ].map((it, i, arr) => (
          <div key={it.label} className="row" style={{
            paddingTop: i > 0 ? 10 : 0, marginTop: i > 0 ? 10 : 0,
          }}>
            <div>
              <div style={{ fontSize:13, color:'var(--c-text)' }}>{it.label}</div>
              {it.has && it.note && (
                <div style={{ fontSize:11, color:'var(--c-text3)', marginTop:1 }}>{it.note}</div>
              )}
            </div>
            <div style={{ fontSize:13, fontWeight:600,
              color: it.has ? '#00E5A8' : '#FF6B6B' }}>
              {it.has ? '✓ In place' : '✗ Missing'}
            </div>
          </div>
        ))}
      </div>

      {/* ── Shock scenarios ────────────────────────────────────────────── */}
      <div style={{ fontSize:11, fontWeight:700, color:'var(--c-text3)',
        textTransform:'uppercase', letterSpacing:.8,
        marginBottom:10, paddingTop:4 }}>
        Shock Scenarios — tap to expand
      </div>
      {shocks.map(s => (
        <ShockCard key={s.id} shock={s}
          fqScore={fq.total} riskScore={risk.total} nw={nw} />
      ))}

      <p className="disclaimer">{BRAND.disclaimer}<br />{BRAND.rulesVersion} · {BRAND.dataDate}</p>

      {/* ── Dimension detail sheet ─────────────────────────────────────── */}
      {activeDim && (
        <DimSheet
          dimCfg={activeDim}
          score={risk.dims[activeDim.key] || 0}
          onClose={() => setActiveDim(null)}
        />
      )}
    </div>
  )
}
