// Settings.jsx — Telegram-style settings overlay
// ─────────────────────────────────────────────────────────────────────────────
// Twelve sections. Phase-1 sections are live; Phase-2 sections show an honest
// blocked state ("Coming in Phase 2") per FP-4 and FP-5. Nothing in here fakes
// functionality that doesn't exist yet.
//
//   S1  My Profile               — live, reads from entity
//   S2  Security                 — Phase 2 (passcode, Face ID, etc.)
//   S3  Financial Details        — live, read-only view of targetIncome etc.
//   S4  Connected Accounts       — Phase 2 (blocked on Part 13 ingest)
//   S5  IFA Access               — live, read-only for demo
//   S6  Document Vault           — Phase 2 (blocked on Part 13)
//   S7  Tax Rules                — live, shows rulesVersion + jurisdiction
//   S8  Finio Score              — live, current score + band
//   S9  Appearance               — live, theme + balance visibility
//   S10 Subscription & Billing   — Phase 2
//   S11 Privacy & Data           — Phase 2 (GDPR export/delete)
//   S12 About                    — live, version + disclaimer
// ─────────────────────────────────────────────────────────────────────────────

import { useState, useEffect } from 'react'
import { BRAND } from '../config/brand.js'
import { calcFQ, fqBand, fmt } from '../engine/fq-calculator.js'
import OverlayShell from '../components/shared/OverlayShell.jsx'

// Coloured icon badge — square, rounded, solid colour background
function Badge({ colour, glyph }) {
  return (
    <div style={{
      width:28, height:28, borderRadius:7, background:colour,
      display:'flex', alignItems:'center', justifyContent:'center',
      flexShrink:0, color:'#fff', fontSize:'var(--fs-body)', fontWeight:700,
      fontFamily:'DM Sans, sans-serif',
    }}>{glyph}</div>
  )
}

// Single row — icon | label | value | chevron
function Row({ colour, glyph, label, value, onClick, phase2=false, danger=false, last=false }) {
  return (
    <div
      onClick={phase2 ? undefined : onClick}
      style={{
        display:'flex', alignItems:'center', gap:12,
        padding:'12px 16px',
        borderBottom: last ? 'none' : '1px solid var(--c-sep)',
        cursor: (phase2 || !onClick) ? 'default' : 'pointer',
        opacity: phase2 ? 0.55 : 1,
      }}>
      <Badge colour={colour} glyph={glyph}/>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:'var(--fs-body)',
          fontWeight: danger ? 700 : 500,
          color: danger ? '#FF453A' : 'var(--c-text)',
          overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
          {label}
        </div>
        {phase2 && (
          <div style={{ fontSize:'var(--fs-label)', color:'var(--c-text3)',
            marginTop:2, textTransform:'uppercase', letterSpacing:0.8 }}>
            Coming in Phase 2
          </div>
        )}
      </div>
      {value != null && (
        <div style={{ fontSize:'var(--fs-small)', color:'var(--c-text3)',
          maxWidth:150, overflow:'hidden', textOverflow:'ellipsis',
          whiteSpace:'nowrap', textAlign:'right' }}>
          {value}
        </div>
      )}
      {!phase2 && !danger && onClick && (
        <span style={{ color:'var(--c-text3)', fontSize:'var(--fs-title)',
          flexShrink:0 }}>›</span>
      )}
    </div>
  )
}

// Section wrapper — header + group of rows
function Section({ title, children }) {
  return (
    <>
      <div style={{ fontSize:'var(--fs-label)', fontWeight:700,
        color:'var(--c-text3)', textTransform:'uppercase', letterSpacing:0.8,
        padding:'16px 16px 6px' }}>
        {title}
      </div>
      <div style={{ background:'var(--c-surface)',
        borderTop:'1px solid var(--c-sep)',
        borderBottom:'1px solid var(--c-sep)' }}>
        {children}
      </div>
    </>
  )
}

// Detail sub-panel — shown when user taps a row that drills in
function DetailPanel({ title, onBack, children }) {
  return (
    <div style={{ position:'absolute', inset:0, background:'var(--c-bg)',
      display:'flex', flexDirection:'column', zIndex:2 }}>
      <div style={{ display:'flex', alignItems:'center', gap:12,
        padding:'12px 16px 10px',
        borderBottom:'1px solid var(--c-sep)', background:'var(--c-bg)',
        flexShrink:0 }}>
        <button onClick={onBack}
          style={{ background:'none', border:'none', color:'var(--c-acc)',
            fontSize:'var(--fs-body)', fontWeight:600, cursor:'pointer',
            padding:0 }}>← Back</button>
        <div style={{ fontSize:'var(--fs-title)', fontWeight:700,
          color:'var(--c-text)' }}>{title}</div>
      </div>
      <div style={{ flex:1, overflowY:'auto', padding:'8px 0 24px' }}>
        {children}
      </div>
    </div>
  )
}

// Info row — label on left, value on right, used inside detail panels
function InfoRow({ label, value, last=false }) {
  return (
    <div style={{ display:'flex', alignItems:'center',
      padding:'12px 16px', gap:12,
      borderBottom: last ? 'none' : '1px solid var(--c-sep)' }}>
      <div style={{ fontSize:'var(--fs-body)', color:'var(--c-text2)', flex:1 }}>
        {label}
      </div>
      <div style={{ fontSize:'var(--fs-body)', color:'var(--c-text)',
        fontWeight:600, textAlign:'right',
        maxWidth:180, overflow:'hidden', textOverflow:'ellipsis',
        whiteSpace:'nowrap' }}>
        {value}
      </div>
    </div>
  )
}

// Pill toggle — Dark / Light selector
function ThemePill({ value, onChange }) {
  const opts = [
    { id:'dark',  label:'Dark'  },
    { id:'light', label:'Light' },
  ]
  return (
    <div style={{ display:'flex', background:'var(--c-surface2)',
      borderRadius:100, padding:3, gap:2 }}>
      {opts.map(o => (
        <button key={o.id} onClick={() => onChange?.(o.id)}
          style={{
            background: value === o.id ? 'var(--c-acc)' : 'transparent',
            color: value === o.id ? '#fff' : 'var(--c-text2)',
            border:'none', cursor:'pointer',
            padding:'6px 14px', borderRadius:100,
            fontSize:'var(--fs-small)', fontWeight:600,
            transition:'background .15s',
          }}>{o.label}</button>
      ))}
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN
// ─────────────────────────────────────────────────────────────────────────────
export default function Settings({ entity, theme='dark', onThemeChange, onClose, onHome }) {
  const [detail, setDetail] = useState(null)   // null | 'profile' | 'financial' | ...
  const [hideBalances, setHideBalances] = useState(false)

  const fq   = calcFQ(entity)
  const band = fqBand(fq.total)

  const rulesVer = entity.rulesVersion || BRAND.rulesVersion
  const dataDate = entity.dataLastUpdated || BRAND.dataDate

  // Escape handled by OverlayShell; local escape here only for detail drill-down
  useEffect(() => {
    function onKey(e) {
      if (e.key === 'Escape' && detail) { setDetail(null); e.stopPropagation() }
    }
    window.addEventListener('keydown', onKey, true)
    return () => window.removeEventListener('keydown', onKey, true)
  }, [detail])

  return (
    <OverlayShell
      title="Settings"
      onBack={() => { if (detail) setDetail(null); else onClose?.() }}
      onHome={onHome}
    >
      <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100%' }}>
        {/* Scroll body */}
        <div style={{ flex:1 }}>
          {/* Identity header */}
          <div style={{ textAlign:'center', padding:'20px 16px 8px' }}>
            <div style={{
              width:64, height:64, borderRadius:'50%',
              background:'linear-gradient(135deg,var(--c-acc),var(--c-acc2))',
              display:'flex', alignItems:'center', justifyContent:'center',
              color:'#fff', fontSize:24, fontWeight:700, margin:'0 auto 10px',
              fontFamily:'DM Sans,sans-serif',
            }}>
              {(entity.displayName || entity.name || '?').charAt(0)}
            </div>
            <div style={{ fontSize:'var(--fs-hero)', fontWeight:800,
              color:'var(--c-text)' }}>
              {entity.displayName || entity.name}
            </div>
            <div style={{ fontSize:'var(--fs-small)', color:'var(--c-text3)',
              marginTop:4, textTransform:'uppercase', letterSpacing:0.8 }}>
            Stage {entity.lifeStage} · {entity.lifeStageName}
          </div>
        </div>

        {/* S1 — Profile + S3 Financial Details */}
        <Section title="Account">
          <Row colour="#4D8EFF" glyph="@"
            label="My Profile"
            value={entity.displayName || entity.name}
            onClick={() => setDetail('profile')}/>
          <Row colour="#00E5A8" glyph="£"
            label="Financial Details"
            value="View"
            onClick={() => setDetail('financial')}/>
          <Row colour="#AF52DE" glyph="◆"
            label="IFA Access"
            value={entity.type === 'ifa' ? 'IFA account' : 'No IFA linked'}
            onClick={() => setDetail('ifa')}
            last={true}/>
        </Section>

        {/* S2 + S4 + S6 — Phase 2 stack */}
        <Section title="Security & Data">
          <Row colour="#FF9500" glyph="▲"
            label="Security" phase2={true} last={false}/>
          <Row colour="#FFB347" glyph="⚲"
            label="Connected Accounts" phase2={true} last={false}/>
          <Row colour="#34C759" glyph="▣"
            label="Document Vault" phase2={true} last={true}/>
        </Section>

        {/* S7 + S8 — Tax & Score */}
        <Section title="Your numbers">
          <Row colour="#FFB347" glyph="§"
            label="Tax Rules"
            value={rulesVer}
            onClick={() => setDetail('taxrules')}/>
          <Row colour={band.colour} glyph="★"
            label="Finio Score"
            value={`${fq.total} · ${band.name}`}
            onClick={() => setDetail('finioscore')}
            last={true}/>
        </Section>

        {/* S9 — Appearance */}
        <Section title="Appearance">
          <div style={{ display:'flex', alignItems:'center', gap:12,
            padding:'12px 16px', borderBottom:'1px solid var(--c-sep)' }}>
            <Badge colour="#8A4AF5" glyph="◐"/>
            <div style={{ flex:1, fontSize:'var(--fs-body)',
              color:'var(--c-text)' }}>Theme</div>
            <ThemePill value={theme} onChange={onThemeChange}/>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:12,
            padding:'12px 16px' }}>
            <Badge colour="#607D8B" glyph="⊘"/>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:'var(--fs-body)', color:'var(--c-text)' }}>
                Hide balances
              </div>
              <div style={{ fontSize:'var(--fs-small)', color:'var(--c-text3)',
                marginTop:2 }}>
                Replaces £ amounts with ••••
              </div>
            </div>
            <button
              onClick={() => setHideBalances(v => !v)}
              style={{
                background: hideBalances ? 'var(--c-acc)' : 'var(--c-surface2)',
                border:'none', borderRadius:100, width:44, height:26,
                cursor:'pointer', position:'relative', padding:0,
                transition:'background .15s',
              }}
              aria-pressed={hideBalances}>
              <div style={{
                width:20, height:20, borderRadius:'50%', background:'#fff',
                position:'absolute', top:3, left: hideBalances ? 21 : 3,
                transition:'left .15s',
              }}/>
            </button>
          </div>
        </Section>

        {/* S10 + S11 — Phase 2 stack */}
        <Section title="Account management">
          <Row colour="#FF453A" glyph="$"
            label="Subscription & Billing" phase2={true}/>
          <Row colour="#6B7280" glyph="◱"
            label="Privacy & Data" phase2={true} last={true}/>
        </Section>

        {/* S12 — About */}
        <Section title="About">
          <Row colour="#4D8EFF" glyph="i"
            label={`About ${BRAND.name}`}
            value={`v${BRAND.version || '1.0'}`}
            onClick={() => setDetail('about')}
            last={true}/>
        </Section>

        {/* Sign out */}
        <div style={{ padding:'20px 16px 12px' }}>
          <div style={{ background:'var(--c-surface)',
            borderTop:'1px solid var(--c-sep)',
            borderBottom:'1px solid var(--c-sep)' }}>
            <Row colour="#FF453A" glyph="→" label="Sign Out"
              danger={true}
              onClick={() => {
                // No auth wired yet (FP-5) — returns to Welcome via parent
                onClose?.()
                if (typeof window !== 'undefined') window.location.href = '/'
              }}
              last={true}/>
          </div>
        </div>

        <div style={{ textAlign:'center', fontSize:'var(--fs-small)',
          color:'var(--c-text3)', padding:'8px 24px 20px', lineHeight:1.6 }}>
          {BRAND.name} · {BRAND.rulesLabel(rulesVer, dataDate)}<br/>
          Not financial advice
        </div>

        <div style={{ height:24 }}/>
      </div>

      {/* ── DETAIL PANELS ─────────────────────────────────────────────────── */}

      {detail === 'profile' && (
        <DetailPanel title="My Profile" onBack={() => setDetail(null)}>
          <InfoRow label="Name"        value={entity.displayName || entity.name || '—'}/>
          <InfoRow label="Age"         value={entity.age || '—'}/>
          <InfoRow label="Life stage"  value={`${entity.lifeStage} · ${entity.lifeStageName}`}/>
          <InfoRow label="Jurisdiction"
            value={entity.jurisdictionContext || 'United Kingdom'}/>
          <InfoRow label="Type"        value={entity.type || 'individual'}/>
          <InfoRow label="Entity ID"   value={entity.id || '—'} last={true}/>
          <div style={{ padding:'16px', fontSize:'var(--fs-small)',
            color:'var(--c-text3)', lineHeight:1.5 }}>
            Profile editing is coming in Phase 2. For now, these values are
            defined in your persona file.
          </div>
        </DetailPanel>
      )}

      {detail === 'financial' && (
        <DetailPanel title="Financial Details" onBack={() => setDetail(null)}>
          <InfoRow label="Target income"
            value={entity.targetIncome ? `${fmt(entity.targetIncome)}/yr` : '—'}/>
          <InfoRow label="Higher-rate taxpayer"
            value={entity.isHigherRateTaxpayer ? 'Yes' : 'No'}/>
          <InfoRow label="Drawdown"
            value={entity.drawdown ? `${fmt(entity.drawdown)}/yr` : 'Not started'}/>
          <InfoRow label="Net worth"
            value={fq.netWorthVal ? fmt(fq.netWorthVal) : '—'} last={true}/>
          <div style={{ padding:'16px', fontSize:'var(--fs-small)',
            color:'var(--c-text3)', lineHeight:1.5 }}>
            These figures are used to calculate your Finio Score. Editing is
            coming in Phase 2 once account linking is live.
          </div>
        </DetailPanel>
      )}

      {detail === 'ifa' && (
        <DetailPanel title="IFA Access" onBack={() => setDetail(null)}>
          {entity.type === 'ifa' ? (
            <>
              <InfoRow label="Account type"  value="Independent Financial Adviser"/>
              <InfoRow label="Firm"          value={entity.firmName || '—'}/>
              <InfoRow label="Client count"  value={entity.clientCount || '—'} last={true}/>
            </>
          ) : (
            <>
              <InfoRow label="Linked IFA" value="None" last={true}/>
              <div style={{ padding:'16px', fontSize:'var(--fs-small)',
                color:'var(--c-text3)', lineHeight:1.5 }}>
                Link an IFA to share your Finio profile securely. Feature
                coming in Phase 2.
              </div>
            </>
          )}
        </DetailPanel>
      )}

      {detail === 'taxrules' && (
        <DetailPanel title="Tax Rules" onBack={() => setDetail(null)}>
          <InfoRow label="Rules version" value={rulesVer}/>
          <InfoRow label="Data as of"    value={dataDate}/>
          <InfoRow label="Jurisdiction"
            value={entity.jurisdictionContext || 'United Kingdom'}/>
          <InfoRow label="Tax year"      value="2026/27 UK" last={true}/>
          <div style={{ padding:'16px', fontSize:'var(--fs-small)',
            color:'var(--c-text3)', lineHeight:1.5 }}>
            Your Finio Score is calculated against the rules version shown.
            When rules change ({BRAND.nextRulesDate || 'Spring Budget'}), you\'ll
            be notified and your score will recalculate automatically.
          </div>
        </DetailPanel>
      )}

      {detail === 'finioscore' && (
        <DetailPanel title="Finio Score" onBack={() => setDetail(null)}>
          <div style={{ textAlign:'center', padding:'32px 16px 20px' }}>
            <div style={{ fontSize:'var(--fs-hero-lg)', fontWeight:800,
              color:band.colour, lineHeight:1 }}>{fq.total}</div>
            <div style={{ fontSize:'var(--fs-body)', color:'var(--c-text2)',
              marginTop:8 }}>{band.name}</div>
          </div>
          <InfoRow label="Score"         value={`${fq.total} / 100`}/>
          <InfoRow label="Band"          value={band.name}/>
          <InfoRow label="Momentum"      value={fq.momentum?.toFixed(2) || '—'}/>
          <InfoRow label="Scoring version" value={fq.scoringVersion || 'FINIO-1.0'} last={true}/>
          <div style={{ padding:'16px', fontSize:'var(--fs-small)',
            color:'var(--c-text3)', lineHeight:1.5 }}>
            Score history and tracking will be added in Phase 2.
          </div>
        </DetailPanel>
      )}

      {detail === 'about' && (
        <DetailPanel title={`About ${BRAND.name}`} onBack={() => setDetail(null)}>
          <InfoRow label="App"              value={BRAND.name}/>
          <InfoRow label="Version"          value={BRAND.version || '1.0'}/>
          <InfoRow label="Rules version"    value={rulesVer}/>
          <InfoRow label="Data last updated" value={dataDate}/>
          <InfoRow label="Scoring"          value="FINIO-1.0"/>
          <InfoRow label="Risk scoring"     value="RISK-1.0" last={true}/>
          <div style={{ padding:'16px', fontSize:'var(--fs-small)',
            color:'var(--c-text3)', lineHeight:1.6 }}>
            {BRAND.disclaimer}
            {'\n\n'}
            {BRAND.name} does not provide financial advice. All figures are
            educational estimates based on data you've provided and current
            tax rules. Consult a qualified adviser before making financial
            decisions.
          </div>
        </DetailPanel>
      )}
      </div>
    </OverlayShell>
  )
}
