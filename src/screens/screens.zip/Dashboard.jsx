// ─────────────────────────────────────────────────────────────────────────────
// Dashboard.jsx — Session 1 rewrite (22 April 2026)
// Changes vs prior:
//   · Uses OverlayShell for FQBreakdown + PersonaSwitcher (D08 / DQ-42)
//   · Threads persona + onCommit callback to children (HomeScreenJit, MyMoney)
//   · Wires Ask tab navigation for SimulatorPanel's onAskAI prop (D05)
//   · FQBreakdown now gets initialTab='actions' when activeDim is set (D04)
// ─────────────────────────────────────────────────────────────────────────────

import { useState, useCallback } from 'react'
import HomeScreen    from './HomeScreen.jsx'
import HomeScreenJit from './HomeScreenJit.jsx'
import FQBreakdown   from './FQBreakdown.jsx'
import MyMoney       from './MyMoney.jsx'
import TaxEstate     from './TaxEstate.jsx'
import Risk          from './Risk.jsx'
import Plan          from './Plan.jsx'
import Ask           from './Ask.jsx'
import Settings      from './Settings.jsx'
import OverlayShell  from '../components/shared/OverlayShell.jsx'
import { calcFQ, fqBand } from '../engine/fq-calculator.js'
import { BRAND } from '../config/brand.js'
import { useEvents } from '../state/events.jsx'

const BARS_MODE = typeof window !== 'undefined'
  && window.location.search.includes('bars')

const TABS = [
  { id:'home',  label:'Home',     icon:'⌂' },
  { id:'money', label:'My Money', icon:'◈' },
  { id:'tax',   label:'Tax',      icon:'⚖' },
  { id:'risk',  label:'Risk',     icon:'◉' },
  { id:'plan',  label:'Timeline', icon:'◷' },
  { id:'ask',   label:'Ask',      icon:'✦' },
]

// ─── Persona switcher — now inside an OverlayShell-like pattern ──────────
function PersonaSwitcher({ personaList, currentPersona, onSelect, onClose }) {
  const TYPE_COLOURS = {
    individual: '#4D8EFF', couple: '#00E5A8', business: '#FFB347',
    ifa: '#AF52DE', life_arc: '#FF9500', nri: '#FF6B6B',
  }

  return (
    <div className="sheet-overlay">
      <div className="sheet-backdrop" onClick={onClose} />
      <div className="sheet-panel" style={{ maxHeight:'80vh' }}>
        <div className="sheet-handle" />
        <div style={{ fontSize:15, fontWeight:800, color:'var(--c-text)',
          marginBottom:16 }}>
          Demo Personas
        </div>
        {personaList.map(p => {
          const isCurrent = currentPersona === p.id ||
            (p.snapshots && p.snapshots.some(s => s.id === currentPersona))
          const col = TYPE_COLOURS[p.type] || '#4D8EFF'
          return (
            <div key={p.id}>
              <div onClick={() => !p.snapshots && onSelect(p.id)}
                style={{
                  display:'flex', alignItems:'center', gap:12,
                  padding:'11px 0',
                  borderBottom:'1px solid var(--c-sep)',
                  cursor: p.snapshots ? 'default' : 'pointer',
                  opacity: 1,
                }}>
                <div style={{
                  width:36, height:36, borderRadius:10, flexShrink:0,
                  background: isCurrent ? col : `${col}22`,
                  display:'flex', alignItems:'center', justifyContent:'center',
                  fontSize:13, fontWeight:800,
                  color: isCurrent ? (col === '#FFB347' ? '#0B1F3A' : '#fff') : col,
                }}>
                  {p.badge}
                </div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:14, fontWeight:600,
                    color:'var(--c-text)' }}>
                    {p.label}
                  </div>
                  <div style={{ fontSize:11, color:'var(--c-text3)',
                    marginTop:1 }}>
                    {p.sub}
                  </div>
                </div>
                {isCurrent && !p.snapshots && (
                  <div style={{ fontSize:11, fontWeight:700, color:col,
                    background:`${col}18`, padding:'2px 8px',
                    borderRadius:100 }}>
                    Active
                  </div>
                )}
              </div>

              {p.snapshots && (
                <div style={{ display:'flex', gap:6, flexWrap:'wrap',
                  padding:'8px 0 12px 48px',
                  borderBottom:'1px solid var(--c-sep)' }}>
                  {p.snapshots.map(s => {
                    const active = currentPersona === s.id
                    return (
                      <button key={s.id} onClick={() => onSelect(s.id)} style={{
                        padding:'5px 12px', borderRadius:100,
                        fontSize:13, fontWeight:600, cursor:'pointer',
                        background: active ? col : `${col}18`,
                        color: active ? '#fff' : col,
                        border: `1px solid ${active ? col : `${col}33`}`,
                      }}>
                        Age {s.age}
                      </button>
                    )
                  })}
                </div>
              )}
            </div>
          )
        })}
        <button onClick={onClose} style={{ width:'100%', marginTop:16,
          background:'var(--c-surface2)', border:'1px solid var(--c-sep)',
          borderRadius:100, padding:'13px 0', fontSize:14,
          fontWeight:600, color:'var(--c-text2)', cursor:'pointer' }}>
          Close
        </button>
      </div>
    </div>
  )
}

export default function Dashboard({ entity, persona, personaList, onSwitchPersona, theme, onThemeChange }) {
  const [tab,          setTab]          = useState('home')
  const [showFQBreak,  setShowFQBreak]  = useState(false)
  const [fqInitialTab, setFqInitialTab] = useState('radar')
  const [fqActiveDim,  setFqActiveDim]  = useState(null)
  const [showSwitcher, setShowSwitcher] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [askContext,   setAskContext]   = useState(null)

  const { commit } = useEvents()

  const fq   = calcFQ(entity)
  const band = fqBand(fq.total)

  // Commit handler passed to any child that produces events
  const handleCommit = useCallback((event) => {
    if (!event || !event.type) return
    commit(persona, event)
  }, [commit, persona])

  // Navigate to Ask tab with optional dim context
  const handleAskAI = useCallback((dimKey) => {
    setAskContext(dimKey ? { dimKey } : null)
    setTab('ask')
  }, [])

  // Open FQBreakdown — accepts optional dim pre-selection (D04 fix)
  const openBreakdown = useCallback((opts = {}) => {
    setFqActiveDim(opts.activeDim || null)
    setFqInitialTab(opts.activeDim ? 'actions' : 'radar')
    setShowFQBreak(true)
  }, [])

  // Navigate to radar home (used by OverlayShell onHome)
  const goHome = useCallback(() => {
    setTab('home')
    setShowFQBreak(false)
    setShowSettings(false)
    setShowSwitcher(false)
  }, [])

  return (
    <div style={{ display:'flex', flexDirection:'column', height:'100vh',
      background:'var(--c-bg)', overflow:'hidden' }}>

      {/* ── Top bar ──────────────────────────────────────────────────────── */}
      <div style={{
        display:'flex', alignItems:'center', justifyContent:'space-between',
        padding:'12px 16px 10px', flexShrink:0, gap:8,
        borderBottom:'1px solid var(--c-sep)',
        background:'var(--c-bg)',
      }}>
        <div style={{ fontSize:'var(--fs-title)', fontWeight:800, color:'var(--c-acc)',
          letterSpacing:-0.5 }}>
          {BRAND.name}
        </div>

        <div onClick={() => setShowSwitcher(true)}
          style={{ textAlign:'center', cursor:'pointer', padding:'2px 8px',
            borderRadius:8, flex:1, minWidth:0 }}>
          <div style={{ fontSize:'var(--fs-body)', fontWeight:600, color:'var(--c-text)',
            overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
            {entity.displayName || entity.name}
          </div>
          <div style={{ fontSize:'var(--fs-label)', color:'var(--c-text3)', marginTop:1,
            textTransform:'uppercase', letterSpacing:0.8 }}>
            Stage {entity.lifeStage} · {entity.lifeStageName} ↕
          </div>
        </div>

        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <button onClick={() => openBreakdown()} style={{
            background:'none', border:'none', cursor:'pointer', padding:0,
            display:'flex', flexDirection:'column', alignItems:'flex-end',
          }}>
            <div style={{ fontSize:'var(--fs-title)', fontWeight:800, color:band.colour,
              lineHeight:1 }}>
              {fq.total}
            </div>
            <div style={{ fontSize:'var(--fs-label)', color:'var(--c-text3)', marginTop:2,
              textTransform:'uppercase', letterSpacing:0.8 }}>
              {band.name}
            </div>
          </button>

          <button onClick={() => setShowSettings(true)} aria-label="Settings" style={{
            width:36, height:36, borderRadius:'50%',
            background:'var(--c-surface2)', border:'1px solid var(--c-border)',
            color:'var(--c-text2)', cursor:'pointer',
            display:'flex', alignItems:'center', justifyContent:'center',
            fontSize:17, lineHeight:1, padding:0, flexShrink:0,
          }}>⚙</button>
        </div>
      </div>

      {/* ── Screen area ──────────────────────────────────────────────────── */}
      <div style={{ flex:1, overflow:'hidden', display:'flex',
        flexDirection:'column' }}>
        {tab === 'home'  && !BARS_MODE && (
          <HomeScreenJit
            entity={entity}
            personaId={persona}
            onNav={(screen) => setTab(screen)}
            onCommit={handleCommit}
            onAskAI={handleAskAI}
            onOpenBreakdown={openBreakdown}
          />
        )}
        {tab === 'home'  &&  BARS_MODE && <HomeScreen entity={entity} onNav={(screen) => setTab(screen)} />}
        {tab === 'money' && (
          <MyMoney
            entity={entity}
            personaId={persona}
            onCommit={handleCommit}
            onHome={goHome}
          />
        )}
        {tab === 'tax'   && <TaxEstate   entity={entity} />}
        {tab === 'risk'  && <Risk        entity={entity} />}
        {tab === 'plan'  && <Plan        entity={entity} />}
        {tab === 'ask'   && <Ask         entity={entity} context={askContext} onClearContext={() => setAskContext(null)} />}
      </div>

      {/* ── Bottom nav ───────────────────────────────────────────────────── */}
      <div style={{
        display:'flex', height:78, flexShrink:0,
        borderTop:'1px solid var(--c-sep)',
        background:'var(--c-bg)',
        paddingBottom:'env(safe-area-inset-bottom, 0px)',
      }}>
        {TABS.map(t => {
          const active = tab === t.id
          return (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              flex:1, display:'flex', flexDirection:'column',
              alignItems:'center', justifyContent:'center', gap:3,
              border:'none', cursor:'pointer', background:'none',
              padding:0, minWidth:0, position:'relative',
            }}>
              {active && (
                <div style={{ position:'absolute', top:8, left:'50%',
                  transform:'translateX(-50%)', width:4, height:4,
                  borderRadius:'50%', background:'var(--c-acc)' }} />
              )}
              <div style={{ fontSize:16, color: active ? 'var(--c-acc)' : 'var(--c-text3)', marginTop:4, transition:'color 0.2s' }}>
                {t.icon}
              </div>
              <div style={{ fontSize:11, fontWeight: active ? 700 : 400,
                color: active ? 'var(--c-acc)' : 'var(--c-text3)',
                transition:'all 0.2s' }}>
                {t.label}
              </div>
            </button>
          )
        })}
      </div>

      {/* ── FQ Breakdown overlay — now uses OverlayShell ─────────────────── */}
      {showFQBreak && (
        <OverlayShell
          title="Score Breakdown"
          subtitle={`${fq.total}/100 · ${band.name}`}
          onBack={() => setShowFQBreak(false)}
          onHome={goHome}
          contentStyle={{ padding: 0 }}
        >
          <FQBreakdown
            entity={entity}
            initialTab={fqInitialTab}
            activeDimKey={fqActiveDim}
            onClose={() => setShowFQBreak(false)}
            embedded={true}
          />
        </OverlayShell>
      )}

      {/* ── Persona switcher (bottom sheet pattern) ──────────────────────── */}
      {showSwitcher && (
        <PersonaSwitcher
          personaList={personaList || []}
          currentPersona={persona}
          onSelect={(id) => { onSwitchPersona(id); setShowSwitcher(false) }}
          onClose={() => setShowSwitcher(false)}
        />
      )}

      {/* ── Settings (uses OverlayShell internally now) ──────────────────── */}
      {showSettings && (
        <Settings
          entity={entity}
          theme={theme}
          onThemeChange={onThemeChange}
          onClose={() => setShowSettings(false)}
          onHome={goHome}
        />
      )}
    </div>
  )
}
