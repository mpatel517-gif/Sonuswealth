function fqBand(score) {
  if (score <= 20) return { name:'Exposed',     c:'#FF6B6B' }
  if (score <= 40) return { name:'Building',    c:'#FFB347' }
  if (score <= 60) return { name:'Established', c:'#4D8EFF' }
  if (score <= 80) return { name:'Optimised',   c:'#00E5A8' }
  return                  { name:'Exceptional', c:'#00E5A8' }
}

function stageFor(age) {
  if (age < 30) return 'Foundation'; if (age < 45) return 'Accumulation'
  if (age < 55) return 'Consolidation'; if (age < 65) return 'Transition'
  if (age < 75) return 'Decumulation'; if (age < 85) return 'Preservation'
  return 'Legacy'
}

export default function Account({ obData, onEnter }) {
  const { age = 38, focus = [], setup = [] } = obData
  const baseScore = Math.round(20 + (age/85)*25 + (focus.length/8)*15 + (setup.length/6)*10)
  const score = Math.min(72, Math.max(18, baseScore))
  const band  = fqBand(score)
  const stage = stageFor(age)

  return (
    <div style={{
      position:'absolute', inset:0, background:'var(--c-bg)',
      display:'flex', alignItems:'center', justifyContent:'center',
      padding:'24px 16px', overflowY:'auto',
    }}>
      <div style={{
        width:'100%', maxWidth:360,
        background:'var(--c-surface)', border:'1px solid var(--c-border2)',
        borderRadius:28, overflow:'hidden', boxShadow:'var(--sh2)',
      }}>
        {/* Blurred preview */}
        <div style={{ position:'relative', height:160, background:'var(--c-bg2)', overflow:'hidden', display:'flex', alignItems:'center', justifyContent:'center' }}>
          <div style={{ position:'absolute', bottom:20, left:0, right:0, display:'flex', gap:8, padding:'0 20px', filter:'blur(6px)', opacity:.4 }}>
            {[1,2,3].map(i => <div key={i} style={{ flex:1, height:48, background:'var(--c-surface)', borderRadius:10 }} />)}
          </div>
          <div style={{ position:'absolute', inset:0, background:'var(--c-bg2)', backdropFilter:'blur(4px)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:8 }}>
            <div style={{ fontSize:32 }}>🔒</div>
            <div style={{ fontSize:13, color:'var(--c-text2)', fontWeight:500 }}>Your dashboard is ready</div>
          </div>
        </div>

        {/* Body */}
        <div style={{ padding:24 }}>
          <div style={{ fontSize:22, fontWeight:800, color:'var(--c-text)', letterSpacing:-.5, marginBottom:6 }}>Unlock your FQ</div>
          <div style={{ fontSize:13, color:'var(--c-text2)', lineHeight:1.5, marginBottom:20 }}>
            Create your free account to see your personalised Financial Quotient dashboard.
          </div>

          {/* FQ preview */}
          <div style={{
            display:'flex', alignItems:'center', gap:12,
            background:'var(--c-surface2)', border:'1px solid var(--c-border2)',
            borderRadius:14, padding:'12px 16px', marginBottom:20,
          }}>
            <div style={{ fontSize:28, fontWeight:800, color: band.c, letterSpacing:-1 }}>{score}</div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:11, color:'var(--c-text3)', textTransform:'uppercase', letterSpacing:.8 }}>Your estimated FQ</div>
              <div style={{ fontSize:13, fontWeight:600, color:'var(--c-text2)', marginTop:2 }}>{band.name} · {stage} · Age {age}</div>
            </div>
          </div>

          {/* Social auth */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:16 }}>
            {[
              { label:'Google', emoji:'G' },
              { label:'Apple',  emoji:'🍎' },
            ].map(b => (
              <button key={b.label} onClick={onEnter} style={{
                padding:12, borderRadius:12,
                background:'var(--c-surface2)', border:'1px solid var(--c-border2)',
                fontSize:13, fontWeight:600, color:'var(--c-text2)',
                display:'flex', alignItems:'center', justifyContent:'center', gap:6,
              }}>
                <span style={{ fontSize:15 }}>{b.emoji}</span> {b.label}
              </button>
            ))}
          </div>

          {/* Divider */}
          <div style={{ display:'flex', alignItems:'center', gap:10, margin:'14px 0', fontSize:13, color:'var(--c-text3)' }}>
            <div style={{ flex:1, height:1, background:'var(--c-border)' }} />
            or
            <div style={{ flex:1, height:1, background:'var(--c-border)' }} />
          </div>

          {/* Email field */}
          <input
            type="email"
            placeholder="Email address"
            style={{
              width:'100%', padding:'14px 16px', marginBottom:10,
              background:'var(--c-surface2)', border:'1.5px solid var(--c-border)',
              borderRadius:14, color:'var(--c-text)', fontSize:15, outline:'none',
              display:'block',
            }}
          />
          <input
            type="password"
            placeholder="Create password"
            style={{
              width:'100%', padding:'14px 16px', marginBottom:16,
              background:'var(--c-surface2)', border:'1.5px solid var(--c-border)',
              borderRadius:14, color:'var(--c-text)', fontSize:15, outline:'none',
              display:'block',
            }}
          />

          <button onClick={onEnter} style={{
            width:'100%', padding:15,
            background:'var(--c-acc)', color:'#0B1F3A',
            borderRadius:100, fontSize:16, fontWeight:700,
            boxShadow:'var(--sh-acc)', marginBottom:10,
          }}>
            Create free account
          </button>

          <div style={{ fontSize:11, color:'var(--c-text3)', textAlign:'center', lineHeight:1.5 }}>
            Your data is encrypted and never sold. By continuing you agree to Finio's Terms of Service.
          </div>
        </div>
      </div>
    </div>
  )
}
