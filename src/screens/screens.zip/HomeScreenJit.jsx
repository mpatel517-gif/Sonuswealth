// HomeScreenJit.jsx — rewrite (Drop 2)
// ─────────────────────────────────────────────────────────────────────────────
// Fixes from 21 April handover:
//   · Zero-spike dot minimum raised (0.06 → 0.25) — dots always sit at/beyond
//     the first grid ring, never collapse into centre
//   · Card position uses precise SVG ref + getBoundingClientRect per tapped dot
//   · DIM_CONFIG removed — now imports shared DIMENSIONS from config/dimensions
//   · Risk/action narrative from entity.dimensionNarrative (persona JSON) — no
//     more Bruce-hardcoded strings
//   · Typography tokens throughout — no hardcoded fontSize below the floor
//   · NWTraj labels derived from engine (guardrail + TAX.brl), not hardcoded
//   · Score-journey narrative derived from fqTrajectory output, not templated
//   · Disclaimer uses BRAND.rulesLabel + entity.rulesVersion (jurisdiction-aware)
// ─────────────────────────────────────────────────────────────────────────────

import { useState, useCallback, useRef, useEffect } from 'react'
import {
  calcFQ, calcRisk, calcFQCalibrated, fqTrajectory, trajectoryData,
  netWorth, costOfInaction, fmt, daysLeft, guardrail,
  TAX,
} from '../engine/fq-calculator.js'
import SimulatorPanel from '../components/Dashboard/SimulatorPanel.jsx'
import TripleAnchor   from '../components/shared/TripleAnchor.jsx'
import { BRAND }      from '../config/brand.js'
import {
  DIMENSIONS, narrativeFor, scoreReactiveFill,
} from '../config/dimensions.js'

// ─────────────────────────────────────────────────────────────────────────────
// RADAR GEOMETRY
// ─────────────────────────────────────────────────────────────────────────────
const SVG_W  = 460
const SVG_H  = 400
const CX     = SVG_W / 2
const CY     = 200
const MAX_R  = 92
const MIN_FRAC = 0.25   // FIX: raised from 0.06 — zero-score dots sit at ring 1

function toRad(deg) { return deg * Math.PI / 180 }
function radarPt(cx, cy, r, deg) {
  return { x: cx + r * Math.cos(toRad(deg)), y: cy + r * Math.sin(toRad(deg)) }
}

// ─────────────────────────────────────────────────────────────────────────────
// RADAR CHART
// ─────────────────────────────────────────────────────────────────────────────
function RadarChart({ entity, fqData, onDimTap, rippleDims }) {
  const [active, setActive] = useState(null)
  const [cardPos, setCardPos] = useState(null)
  const wrapRef = useRef(null)
  const svgRef  = useRef(null)

  const fracs = DIMENSIONS.map(d => ({
    ...d,
    score: fqData.dims[d.key] || 0,
    frac:  Math.min(1, (fqData.dims[d.key] || 0) / d.max),
  }))

  const dataPts  = fracs.map(d => radarPt(CX, CY, Math.max(MIN_FRAC, d.frac) * MAX_R, d.angle))
  const dataPath = dataPts.map((p,i) => `${i===0?'M':'L'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ') + ' Z'

  const spikePaths = fracs.map((d, i) => {
    const prev = fracs[(i + fracs.length - 1) % fracs.length]
    const next = fracs[(i + 1) % fracs.length]
    const tip  = radarPt(CX, CY, Math.max(MIN_FRAC, d.frac) * MAX_R, d.angle)
    const lp   = radarPt(CX, CY, Math.max(MIN_FRAC, prev.frac) * MAX_R, prev.angle)
    const np   = radarPt(CX, CY, Math.max(MIN_FRAC, next.frac) * MAX_R, next.angle)
    return `M ${CX},${CY} L ${lp.x.toFixed(1)},${lp.y.toFixed(1)} L ${tip.x.toFixed(1)},${tip.y.toFixed(1)} L ${np.x.toFixed(1)},${np.y.toFixed(1)} Z`
  })

  const nw = netWorth(entity)

  const positionCardFor = useCallback((idx) => {
    if (idx == null || !wrapRef.current || !svgRef.current) return null
    const wrapRect = wrapRef.current.getBoundingClientRect()
    const svgRect  = svgRef.current.getBoundingClientRect()
    const scaleX = svgRect.width  / SVG_W
    const scaleY = svgRect.height / SVG_H
    const pt = dataPts[idx]
    const left = (svgRect.left - wrapRect.left) + pt.x * scaleX
    const top  = (svgRect.top  - wrapRect.top)  + pt.y * scaleY + 60
    return { left, top }
  }, [dataPts])

  const handleTap = useCallback((idx) => {
    if (active === idx) { setActive(null); setCardPos(null) }
    else { setActive(idx); setCardPos(positionCardFor(idx)) }
  }, [active, positionCardFor])

  useEffect(() => {
    function onResize() {
      if (active != null) setCardPos(positionCardFor(active))
    }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [active, positionCardFor])

  return (
    <div ref={wrapRef} style={{ position:'relative', width:'100%' }}>
      <svg ref={svgRef} viewBox={`0 0 ${SVG_W} ${SVG_H}`} width="100%"
        style={{ display:'block', overflow:'visible' }}>
        {[0.25, 0.5, 0.75, 1.0].map(r => (
          <circle key={r} cx={CX} cy={CY} r={r * MAX_R}
            fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="0.75"/>
        ))}

        {DIMENSIONS.map((d, i) => {
          const o = radarPt(CX, CY, MAX_R, d.angle)
          return (
            <line key={i} x1={CX} y1={CY} x2={o.x.toFixed(1)} y2={o.y.toFixed(1)}
              stroke="rgba(138,155,192,0.08)" strokeWidth="0.75"/>
          )
        })}

        {fracs.map((d, i) => (
          <path key={i} d={spikePaths[i]}
            fill={scoreReactiveFill(d.colour, d.frac)}
            stroke="none"
            style={{ cursor:'pointer', transition:'fill .2s' }}
            onClick={() => handleTap(i)}/>
        ))}

        <path d={dataPath} fill="none"
          stroke="rgba(255,255,255,0.15)" strokeWidth="1" strokeLinejoin="round"/>

        {dataPts.map((p, i) => {
          const d        = fracs[i]
          const isActive = active === i
          const dotR     = 20
          const pct      = Math.round(d.frac * 100)
          return (
            <g key={i} style={{ cursor:'pointer' }} onClick={() => handleTap(i)}>
              <circle cx={p.x} cy={p.y} r="34" fill="transparent"/>
              {rippleDims?.includes(d.key) && (
                <circle cx={p.x} cy={p.y} r={dotR+6} fill="none"
                  stroke={d.colour} strokeWidth="1.5" opacity="0.5" strokeDasharray="3 3"/>
              )}
              <circle cx={p.x} cy={p.y} r={isActive ? dotR+3 : dotR}
                fill={d.colour}
                stroke={isActive ? '#fff' : 'rgba(8,14,26,0.8)'}
                strokeWidth={isActive ? 2.5 : 1.5}
                style={{ transition:'all .15s' }}/>
              <text x={p.x} y={p.y+5} fontSize="13" fontWeight="700"
                fill={pct > 60 ? '#0B1F3A' : '#fff'}
                textAnchor="middle" fontFamily="DM Sans,sans-serif">{pct}%</text>
            </g>
          )
        })}

        {DIMENSIONS.map((d, i) => {
          const lp = radarPt(CX, CY, MAX_R + 32, d.angle)
          const anchor = lp.x > CX + 8 ? 'start' : lp.x < CX - 8 ? 'end' : 'middle'
          const words = d.label.split(' ')
          return words.length === 1 ? (
            <text key={i} x={lp.x} y={lp.y+4} fontSize="13" fontWeight="700"
              fill={d.colour} textAnchor={anchor} fontFamily="DM Sans,sans-serif">
              {d.label}
            </text>
          ) : (
            <text key={i} textAnchor={anchor} fontFamily="DM Sans,sans-serif">
              <tspan x={lp.x} y={lp.y-4} fontSize="13" fontWeight="700" fill={d.colour}>
                {words[0]}
              </tspan>
              <tspan x={lp.x} dy="16" fontSize="13" fontWeight="700" fill={d.colour}>
                {words.slice(1).join(' ')}
              </tspan>
            </text>
          )
        })}

        <circle cx={CX} cy={CY} r="42" fill="rgba(8,14,26,0.92)"
          stroke="rgba(255,255,255,0.10)" strokeWidth="1"/>
        <text x={CX} y={CY-6} fontSize="11" fontWeight="600"
          fill="rgba(138,155,192,0.7)" textAnchor="middle"
          fontFamily="DM Sans,sans-serif" letterSpacing="0.8">
          YOU OWN
        </text>
        <text x={CX} y={CY+11} fontSize="14" fontWeight="800" fill="#F0F4FF"
          textAnchor="middle" fontFamily="DM Sans,sans-serif">
          {fmt(nw)}
        </text>
      </svg>

      {active !== null && cardPos !== null && (() => {
        const d    = fracs[active]
        const pct  = Math.round(d.frac * 100)
        const narr = narrativeFor(entity, d.key)
        const wrapW = wrapRef.current?.clientWidth || 460

        return (
          <div
            onClick={() => { onDimTap(d.key); setActive(null); setCardPos(null) }}
            style={{
              position:'absolute',
              left: Math.max(16, Math.min(cardPos.left - 150, wrapW - 316)),
              top:  cardPos.top,
              width: 'calc(100% - 32px)',
              maxWidth: 300,
              zIndex:10,
              background:'var(--c-surface)',
              border:`1.5px solid ${d.colour}`,
              borderRadius:16,
              padding:'14px 16px',
              boxShadow:'0 8px 32px rgba(0,0,0,0.7)',
              cursor:'pointer',
            }}>
            <div style={{ display:'flex', justifyContent:'space-between',
              alignItems:'center', marginBottom:8 }}>
              <span style={{ fontSize:'var(--fs-body)', fontWeight:700, color:d.colour }}>
                {d.label}
              </span>
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <span style={{ fontSize:'var(--fs-small)', fontWeight:600,
                  color:'var(--c-text)' }}>{pct}%</span>
                <button
                  onClick={e => { e.stopPropagation(); setActive(null); setCardPos(null) }}
                  aria-label="Close"
                  style={{
                    padding:'3px 9px', borderRadius:8,
                    fontSize:'var(--fs-small)',
                    color:'var(--c-text3)', background:'rgba(255,255,255,.06)',
                    border:'1px solid rgba(255,255,255,.1)', cursor:'pointer',
                  }}>✕</button>
              </div>
            </div>

            <p style={{ fontSize:'var(--fs-body)', color:'var(--c-text2)',
              lineHeight:1.5, margin:'0 0 10px' }}>
              {d.definition}
            </p>

            {pct < 70 && (
              <p style={{ fontSize:'var(--fs-small)', color:d.colour,
                lineHeight:1.5, margin:'0 0 10px',
                padding:'8px 10px', background: d.colour + '15', borderRadius:8 }}>
                {narr.risk}
              </p>
            )}

            <div style={{ display:'flex', alignItems:'center',
              justifyContent:'space-between',
              background: d.colour + '18', borderRadius:10, padding:'10px 14px' }}>
              <span style={{ fontSize:'var(--fs-body)', fontWeight:600,
                color:d.colour }}>
                {pct < 70 ? 'See what you can do →' : 'Explore this area →'}
              </span>
              <span style={{ fontSize:'var(--fs-label)', color:'var(--c-text3)',
                textTransform:'uppercase', letterSpacing:0.8 }}>
                tap anywhere
              </span>
            </div>
          </div>
        )
      })()}
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// NET WORTH TRAJECTORY — series labels from engine, not hardcoded to Bruce
// ─────────────────────────────────────────────────────────────────────────────
function NWTraj({ entity }) {
  const [callout, setCallout] = useState(null)
  const data  = trajectoryData(entity)
  const guard = Math.round(guardrail(entity))
  const brl   = TAX?.brl || 50270
  const draw25 = Math.min(25000, guard)
  const draw37 = Math.min(brl - 11973, guard)

  const all  = [...data.doNothing, ...data.draw25, ...data.draw377].map(d => d.nw)
  const maxV = Math.max(...all)
  const ages = data.doNothing.map(d => d.age)
  const W=320, H=100, pL=6, pR=6, pT=8, pB=20, pw=W-pL-pR, ph=H-pT-pB
  const px = age => pL + ((age - ages[0]) / (ages[ages.length-1] - ages[0])) * pw
  const py = nw  => pT + ph - ((nw / maxV) * ph)

  function cr(pts) {
    let d = `M${pts[0].x.toFixed(1)},${pts[0].y.toFixed(1)}`
    for (let i=0; i<pts.length-1; i++) {
      const p0=pts[Math.max(0,i-1)], p1=pts[i], p2=pts[i+1]
      const p3=pts[Math.min(pts.length-1,i+2)]
      d += ` C${(p1.x+(p2.x-p0.x)/6).toFixed(1)},${(p1.y+(p2.y-p0.y)/6).toFixed(1)} `
         + `${(p2.x-(p3.x-p1.x)/6).toFixed(1)},${(p2.y-(p3.y-p1.y)/6).toFixed(1)} `
         + `${p2.x.toFixed(1)},${p2.y.toFixed(1)}`
    }
    return d
  }

  const series = [
    { d:data.doNothing, c:'#FF6B6B', w:1.8, label:'Do nothing' },
    { d:data.draw25,    c:'#4D8EFF', w:2.0, label:`Draw ${fmt(draw25)}/yr` },
    { d:data.draw377,   c:'#00E5A8', w:2.5, label:`Draw ${fmt(draw37)}/yr` },
  ]

  return (
    <div style={{ margin:'0 16px 10px', background:'var(--c-surface)',
      border:'1px solid rgba(255,255,255,.06)', borderRadius:20, padding:16 }}>
      <div style={{ display:'flex', alignItems:'center',
        justifyContent:'space-between', marginBottom:8, flexWrap:'wrap', gap:8 }}>
        <div style={{ fontSize:'var(--fs-body)', fontWeight:700,
          color:'var(--c-text)' }}>
          What you own — to age 90
        </div>
        <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}>
          {series.map(s => (
            <div key={s.label} style={{ display:'flex', alignItems:'center',
              gap:5, fontSize:'var(--fs-small)', color:'var(--c-text2)' }}>
              <div style={{ width:14, height:3, borderRadius:100, background:s.c }}/>
              {s.label}
            </div>
          ))}
        </div>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" style={{ overflow:'visible' }}>
        {ages.map(a => (
          <text key={a} x={px(a).toFixed(0)} y={H} textAnchor="middle"
            fontSize="11" fill="#4A5878" fontFamily="DM Sans,sans-serif">{a}</text>
        ))}
        {series.map(s => {
          const pts = s.d.map(p => ({ x:px(p.age), y:py(p.nw) }))
          return (
            <path key={s.label} d={cr(pts)} fill="none"
              stroke={s.c} strokeWidth={s.w} strokeLinecap="round"/>
          )
        })}
        {data.draw377.map(p => (
          <circle key={p.age} cx={px(p.age).toFixed(1)} cy={py(p.nw).toFixed(1)}
            r="3" fill="#00E5A8" stroke="rgba(8,14,26,.8)" strokeWidth="1.5"
            onClick={() => setCallout(callout===p.age ? null : p.age)}
            style={{ cursor:'pointer' }}/>
        ))}
      </svg>
      {callout && (() => {
        const dn  = data.doNothing.find(p => p.age===callout)
        const d25 = data.draw25.find(p => p.age===callout)
        const d37 = data.draw377.find(p => p.age===callout)
        return (
          <div style={{ background:'rgba(23,32,54,.98)',
            border:'1px solid rgba(255,255,255,.1)',
            borderRadius:10, padding:'10px 12px', marginTop:8 }}>
            <div style={{ fontSize:'var(--fs-small)', fontWeight:700,
              color:'var(--c-text)', marginBottom:5 }}>Age {callout}</div>
            <div style={{ display:'flex', gap:12, flexWrap:'wrap' }}>
              <span style={{ fontSize:'var(--fs-small)', fontWeight:600,
                color:'#FF6B6B' }}>Do nothing: {fmt(dn?.nw)}</span>
              <span style={{ fontSize:'var(--fs-small)', fontWeight:600,
                color:'#4D8EFF' }}>{fmt(draw25)}/yr: {fmt(d25?.nw)}</span>
              <span style={{ fontSize:'var(--fs-small)', fontWeight:600,
                color:'#00E5A8' }}>{fmt(draw37)}/yr: {fmt(d37?.nw)}</span>
            </div>
          </div>
        )
      })()}
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// ALERT CARDS
// ─────────────────────────────────────────────────────────────────────────────
function AlertCards({ entity, onNav }) {
  const alerts = entity.alerts || []
  if (alerts.length === 0) return null
  return (
    <>
      <div style={{ display:'flex', alignItems:'center',
        justifyContent:'space-between', padding:'16px 16px 8px' }}>
        <div style={{ fontSize:'var(--fs-label)', fontWeight:700,
          color:'var(--c-text2)',
          textTransform:'uppercase', letterSpacing:0.8 }}>
          Things to look at
        </div>
        <div style={{ fontSize:'var(--fs-body)', fontWeight:600, color:'var(--c-acc)' }}>
          {alerts.length} items
        </div>
      </div>
      {alerts.map((a, i) => (
        <div key={i} className={`alert-card ${a.level}`}
          onClick={() => onNav(a.screen || 'ask')}>
          <div className="ac-inner">
            <div className="ac-top">
              <div className="ac-badge">{a.badge}</div>
              <div className="ac-days">{a.days}</div>
            </div>
            <div className="ac-title">{a.headline}</div>
            <div className="ac-body">{a.context}</div>
            <div className="ac-foot">
              <div className="ac-cta">{a.action}</div>
              <span style={{ color:'var(--c-text3)', fontSize:'var(--fs-title)' }}>›</span>
            </div>
          </div>
        </div>
      ))}
    </>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN
// ─────────────────────────────────────────────────────────────────────────────
export default function HomeScreenJit({
  entity, onNav, personaId, onCommit, onAskAI, onOpenBreakdown,
}) {
  const [activeDimKey,  setActiveDimKey]  = useState(null)
  const [panelOpen,     setPanelOpen]     = useState(false)
  const [simResult,     setSimResult]     = useState(null)
  const [rippleDims,    setRippleDims]    = useState([])

  const baseFQData   = calcFQCalibrated(entity)
  const fqData       = simResult ? simResult.fqData : baseFQData
  const riskData     = calcRisk(entity)
  const coi          = costOfInaction(entity)
  const dl           = daysLeft()
  const traj         = fqTrajectory(entity)
  const isSimulating = simResult !== null
  const deltaFQ      = simResult ? simResult.deltaFQ : 0

  const handleDimTap   = useCallback((dimKey) => {
    setActiveDimKey(dimKey); setPanelOpen(true)
  }, [])
  const handleSimulate = useCallback((result) => {
    setSimResult(result); setRippleDims(result.rippleDims || [])
  }, [])
  const handlePanelClose = useCallback(() => { setPanelOpen(false) }, [])
  const handleResetSim   = useCallback(() => {
    setSimResult(null); setRippleDims([]); setActiveDimKey(null); setPanelOpen(false)
  }, [])

  const rulesVer = entity.rulesVersion || BRAND.rulesVersion
  const dataDate = entity.dataLastUpdated || BRAND.dataDate

  const journeyTail = traj && traj.length >= 4
    ? `Take one action → ${traj[2]?.score} in 6 months · All actions → ${traj[3]?.score}`
    : null

  return (
    <div style={{ overflowY:'auto', height:'100%' }}>
      <div style={{ fontSize:'var(--fs-label)', color:'var(--c-text3)',
        padding:'8px 16px 0', textTransform:'uppercase', letterSpacing:0.8 }}>
        Rules: {rulesVer} · {dataDate}
      </div>

      <TripleAnchor
        netWorthVal={netWorth(entity)}
        fqTotal={fqData.total}
        fqBand={fqData.band}
        riskTotal={riskData.total}
        riskBand={riskData.band}
        deltaFQ={deltaFQ}
        isSimulating={isSimulating}/>

      <div style={{ margin:'10px 16px 0', height:5, background:'rgba(255,255,255,.06)',
        borderRadius:100, overflow:'hidden' }}>
        <div style={{ height:'100%', borderRadius:100, width:`${fqData.total}%`,
          background:'linear-gradient(90deg,#FF6B6B,#FFB347,#4D8EFF,#00E5A8)',
          transition:'width .4s cubic-bezier(.4,0,.2,1)' }}/>
      </div>
      <div style={{ display:'flex', justifyContent:'space-between',
        padding:'4px 16px 0', fontSize:'var(--fs-label)', color:'var(--c-text3)',
        textTransform:'uppercase', letterSpacing:0.8 }}>
        {['Exposed','Building','Established','Optimised','Exceptional'].map(b =>
          <span key={b}>{b}</span>
        )}
      </div>

      {coi > 0 && dl > 0 && (
        <div style={{ margin:'10px 16px 0', background:'rgba(255,149,0,.08)',
          borderLeft:'3px solid #FF9500', borderRadius:'0 10px 10px 0',
          padding:'10px 14px', fontSize:'var(--fs-body)', fontWeight:600,
          color:'rgba(255,149,0,.95)' }}>
          Cost of not acting: {fmt(coi)} · {dl} days left
        </div>
      )}

      <div style={{ padding:'6px 0 0' }}>
        <RadarChart entity={entity} fqData={fqData}
          onDimTap={handleDimTap} rippleDims={rippleDims}/>
      </div>

      {panelOpen && activeDimKey && (
        <div style={{ margin:'14px 0 0', borderRadius:'20px 20px 0 0',
          overflow:'hidden', boxShadow:'0 -4px 40px rgba(0,0,0,0.5)' }}>
          <SimulatorPanel
            entity={entity}
            activeDimKey={activeDimKey}
            baseFQTotal={baseFQData.total}
            onSimulate={handleSimulate}
            onClose={handlePanelClose}
            onAskAI={onAskAI}
            onCommit={(payload) => {
              // Simulator commit → dispatch DRAWDOWN_COMMITTED event when
              // the user's overrides include a new drawdown value. Other
              // slider commits are stub-only in Session 1 (event stub scope).
              if (onCommit && payload?.overrides?.drawdown !== undefined) {
                onCommit({
                  type: 'drawdown_committed',
                  payload: {
                    annual: payload.overrides.drawdown,
                    startAge: (entity.age || 62) + 1,
                  },
                })
              }
              handleResetSim()
            }}/>
        </div>
      )}

      {isSimulating && (
        <div style={{ display:'flex', justifyContent:'center', padding:'10px 0 0' }}>
          <button onClick={handleResetSim}
            style={{ background:'rgba(255,255,255,.06)',
              border:'1px solid rgba(255,255,255,.12)',
              borderRadius:100, padding:'8px 20px',
              fontSize:'var(--fs-small)', fontWeight:600,
              color:'var(--c-text2)', cursor:'pointer' }}>
            Reset simulation
          </button>
        </div>
      )}

      <div style={{ display:'flex', alignItems:'center',
        justifyContent:'space-between', padding:'16px 16px 8px' }}>
        <div style={{ fontSize:'var(--fs-label)', fontWeight:700,
          color:'var(--c-text2)',
          textTransform:'uppercase', letterSpacing:0.8 }}>
          Your score journey
        </div>
        <div style={{ fontSize:'var(--fs-body)', fontWeight:600,
          color:'var(--c-acc)', cursor:'pointer' }}
          onClick={() => onOpenBreakdown?.({ activeDim: activeDimKey })}>Full breakdown →</div>
      </div>
      <div style={{ margin:'0 16px 10px', background:'var(--c-surface)',
        border:'1px solid rgba(255,255,255,.06)', borderRadius:16, padding:14 }}>
        <div style={{ display:'flex', justifyContent:'space-between', marginBottom:10 }}>
          {traj.map(t => (
            <div key={t.label} style={{ textAlign:'center' }}>
              <div style={{ fontSize:'var(--fs-title)', fontWeight:800, color:t.colour }}>
                {t.score}
              </div>
              <div style={{ fontSize:'var(--fs-label)', color:'var(--c-text3)',
                marginTop:3, textTransform:'uppercase', letterSpacing:0.8 }}>
                {t.label}
              </div>
            </div>
          ))}
        </div>
        <div style={{ height:4, background:'rgba(255,255,255,.06)',
          borderRadius:100, overflow:'hidden' }}>
          <div style={{ height:'100%', width:`${baseFQData.total}%`,
            background:'linear-gradient(90deg,#FF6B6B,#FFB347,#4D8EFF,#00E5A8)',
            borderRadius:100 }}/>
        </div>
        {journeyTail && (
          <div style={{ fontSize:'var(--fs-small)', color:'var(--c-text2)',
            marginTop:8, lineHeight:1.5 }}>
            {journeyTail}
          </div>
        )}
      </div>

      <div style={{ fontSize:'var(--fs-label)', fontWeight:700,
        color:'var(--c-text2)',
        textTransform:'uppercase', letterSpacing:0.8,
        padding:'4px 16px 8px' }}>
        What you own — over time
      </div>
      <NWTraj entity={entity}/>

      <AlertCards entity={entity} onNav={onNav}/>

      <div style={{ textAlign:'center', fontSize:'var(--fs-small)',
        color:'var(--c-text3)', padding:'16px 24px 8px', lineHeight:1.6 }}>
        {BRAND.disclaimer}<br/>
        {BRAND.rulesLabel(rulesVer, dataDate)}
      </div>
      <div style={{ height:16 }}/>
    </div>
  )
}
