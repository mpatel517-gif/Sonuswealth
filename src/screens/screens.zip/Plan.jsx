import { useState } from 'react'
import { fmt, daysLeft, fqTrajectory, fqBand } from '../engine/fq-calculator.js'
import { BRAND } from '../config/brand.js'

// ── Life stage bar ────────────────────────────────────────────────────────
const STAGES = [
  { n:1, name:'Foundation',    range:'18–30' },
  { n:2, name:'Accumulation',  range:'30–45' },
  { n:3, name:'Consolidation', range:'45–55' },
  { n:4, name:'Transition',    range:'55–65' },
  { n:5, name:'Decumulation',  range:'65–75' },
  { n:6, name:'Preservation',  range:'75–85' },
  { n:7, name:'Legacy',        range:'85+'   },
]

function StageBar({ entity }) {
  const current = entity.lifeStage || 1
  const stage   = STAGES.find(s => s.n === current) || STAGES[0]
  return (
    <div className="card">
      <div style={{ display:'flex', justifyContent:'space-between',
        alignItems:'center', marginBottom:12 }}>
        <div className="card-title" style={{ marginBottom:0 }}>
          Life Stage
        </div>
        <div style={{ fontSize:11, fontWeight:600, color:'var(--c-acc)',
          background:'var(--c-acc-bg)', padding:'3px 9px', borderRadius:100 }}>
          Stage {current} · {stage.name}
        </div>
      </div>
      <div style={{ display:'flex', gap:3, marginBottom:8 }}>
        {STAGES.map(s => (
          <div key={s.n} style={{ flex:1, height:5, borderRadius:100,
            background: s.n === current ? 'var(--c-acc)' :
                        s.n < current  ? 'rgba(0,229,168,.35)' :
                        'rgba(255,255,255,.07)',
            transition:'background .3s',
          }} />
        ))}
      </div>
      <div style={{ display:'flex', justifyContent:'space-between',
        fontSize:11, color:'var(--c-text3)' }}>
        <span>18</span>
        <span style={{ color:'var(--c-acc)', fontWeight:600 }}>
          {stage.range}
        </span>
        <span>85+</span>
      </div>
    </div>
  )
}

// ── Score trajectory ──────────────────────────────────────────────────────
function ScoreTraj({ entity }) {
  const traj = fqTrajectory(entity)
  return (
    <div className="card">
      <div className="card-title">Score Journey — What Actions Unlock</div>
      <div style={{ display:'flex', justifyContent:'space-between',
        alignItems:'flex-end', gap:4, marginBottom:12 }}>
        {traj.map(pt => {
          const band = fqBand(pt.score)
          const h    = Math.round((pt.score / 100) * 72)
          return (
            <div key={pt.label} style={{ flex:1, display:'flex',
              flexDirection:'column', alignItems:'center', gap:4 }}>
              <div style={{ fontSize:15, fontWeight:800,
                color:band.colour }}>{pt.score}</div>
              <div style={{ width:'100%', height:h,
                background:band.colour, borderRadius:'5px 5px 0 0',
                minHeight:4, opacity:.85,
                transition:'height .4s ease' }} />
              <div style={{ fontSize:11, color:'var(--c-text3)',
                textAlign:'center', lineHeight:1.3 }}>{pt.label}</div>
            </div>
          )
        })}
      </div>
      <div style={{ height:3, background:'rgba(255,255,255,.06)',
        borderRadius:100, overflow:'hidden', marginBottom:8 }}>
        <div style={{ height:'100%', borderRadius:100,
          width:`${traj[0]?.score || 0}%`,
          background:'linear-gradient(90deg,#FF6B6B,#FFB347,#4D8EFF,#00E5A8)' }}
        />
      </div>
      <div style={{ fontSize:13, color:'var(--c-text2)', lineHeight:1.6 }}>
        Taking all recommended actions moves your score from{' '}
        <strong style={{ color:'#FF6B6B' }}>{traj[0]?.score}</strong> to{' '}
        <strong style={{ color:'#00E5A8' }}>{traj[traj.length-1]?.score}</strong>
      </div>
    </div>
  )
}

// ── Action calendar event ─────────────────────────────────────────────────
function CalendarEvent({ event, isLast, onTap }) {
  const urgencyCol = {
    critical: '#FF3B30', high: '#FF9500',
    medium: '#4D8EFF', info: '#34C759',
  }
  const col = urgencyCol[event.level] || 'var(--c-acc2)'

  return (
    <div style={{ display:'flex', gap:14, marginBottom:0 }}>
      {/* Spine */}
      <div style={{ display:'flex', flexDirection:'column',
        alignItems:'center', flexShrink:0 }}>
        <div style={{
          width:12, height:12, borderRadius:'50%', marginTop:4,
          background: event.bg || 'var(--c-surface2)',
          border:`2px solid ${col}`, flexShrink:0,
          fontSize:11, display:'flex', alignItems:'center',
          justifyContent:'center',
        }}>
          {event.dot}
        </div>
        {!isLast && (
          <div style={{ width:2, flex:1, background:'var(--c-sep)',
            marginTop:4, minHeight:24 }} />
        )}
      </div>

      {/* Card */}
      <div onClick={() => onTap(event)} style={{
        flex:1, background:'var(--c-surface)',
        border:'1px solid var(--c-sep)', borderRadius:14,
        padding:'10px 14px', marginBottom:10, cursor:'pointer',
        transition:'border-color .15s',
      }}>
        <div style={{ display:'flex', justifyContent:'space-between',
          alignItems:'flex-start', marginBottom:4 }}>
          <div style={{ fontSize:13, fontWeight:700, color:'var(--c-text)',
            flex:1, marginRight:8 }}>
            {event.title}
          </div>
          <div style={{ fontSize:11, color:'var(--c-text3)',
            flexShrink:0 }}>{event.date}</div>
        </div>
        {event.sub && (
          <div style={{ fontSize:13, color:'var(--c-text2)',
            lineHeight:1.5 }}>{event.sub}</div>
        )}
      </div>
    </div>
  )
}

// ── Upcoming deadlines from alerts ────────────────────────────────────────
function UpcomingDeadlines({ entity }) {
  const days   = daysLeft()
  const sipp   = entity.assets?.sipp?.total || 0
  const urgent = sipp > 0 && days < 400

  const deadlines = [
    {
      date:`${days} days`, title:'SIPP enters estate for IHT',
      sub:`${daysLeft()} days to 6 April 2027. Review drawdown options.`,
      dot:'⏳', bg:'#FFF3F3', level:'critical',
      applicable: urgent,
    },
    {
      date:'Annually', title:'ISA allowance — use or lose',
      sub:`£20,000 ISA allowance resets 6 April. Unused allowance does not carry forward.`,
      dot:'🏦', bg:'#E8F7EF', level:'medium',
      applicable: true,
    },
    {
      date:'Annually', title:'CGT allowance — £3,000',
      sub:'Bed-and-ISA opportunity. Crystallise gains within allowance to move assets into tax-free wrapper.',
      dot:'📊', bg:'#EEF2FF', level:'medium',
      applicable: (entity.assets?.portfolio?.value || 0) > 0,
    },
    ...(entity.assets?.trustGifts ? [{
      date:'7-year clock',
      title:'Trust gift taper relief',
      sub:`${fmt(entity.assets.trustGifts.total)} gifted ${entity.assets.trustGifts.date}. IHT reduces each year.`,
      dot:'🎁', bg:'#FFF8E8', level:'info',
      applicable: true,
    }] : []),
    {
      date:`Age ${entity.income?.statePension?.startAge || 67}`,
      title:'State Pension begins',
      sub:`£${((entity.income?.statePension?.annual||11973)/1000).toFixed(0)}k/yr — reduces drawdown requirement and income tax position.`,
      dot:'🏛', bg:'#F0F4FF', level:'info',
      applicable: (entity.age || 0) < (entity.income?.statePension?.startAge || 67),
    },
  ].filter(d => d.applicable)

  return (
    <div>
      <div style={{ fontSize:11, fontWeight:700, color:'var(--c-text3)',
        textTransform:'uppercase', letterSpacing:.8,
        marginBottom:12 }}>
        Action Calendar
      </div>
      {deadlines.map((d, i) => (
        <CalendarEvent key={i} event={d} isLast={i === deadlines.length - 1}
          onTap={() => {}} />
      ))}
    </div>
  )
}

// ── Personal timeline ─────────────────────────────────────────────────────
function PersonalTimeline({ entity }) {
  const [selected, setSelected] = useState(null)
  const timeline = entity.timeline || []
  if (!timeline.length) return null

  return (
    <div>
      <div style={{ fontSize:11, fontWeight:700, color:'var(--c-text3)',
        textTransform:'uppercase', letterSpacing:.8,
        marginBottom:12 }}>
        Your Timeline
      </div>
      {timeline.map((item, i) => (
        <CalendarEvent key={i} event={item}
          isLast={i === timeline.length - 1}
          onTap={setSelected} />
      ))}

      {/* Detail sheet */}
      {selected && (
        <div className="sheet-overlay">
          <div className="sheet-backdrop" onClick={() => setSelected(null)} />
          <div className="sheet-panel">
            <div className="sheet-handle" />
            <div style={{ textAlign:'center', marginBottom:16 }}>
              <div style={{ fontSize:28, marginBottom:8 }}>{selected.dot}</div>
              <div style={{ fontSize:18, fontWeight:800,
                color:'var(--c-text)', marginBottom:4 }}>
                {selected.title}
              </div>
              <div style={{ fontSize:13, color:'var(--c-text3)' }}>
                {selected.date}
              </div>
            </div>
            {selected.sub && (
              <div style={{ fontSize:14, color:'var(--c-text2)',
                lineHeight:1.7, textAlign:'center', marginBottom:20 }}>
                {selected.sub}
              </div>
            )}
            <button onClick={() => setSelected(null)} style={{
              width:'100%', background:'var(--c-acc)', color:'#000',
              border:'none', borderRadius:100, padding:'13px 0',
              fontSize:14, fontWeight:700, cursor:'pointer',
            }}>
              Got it
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

// ── Main export ───────────────────────────────────────────────────────────
export default function Plan({ entity }) {
  return (
    <div className="screen">
      <div style={{ textAlign:'right', fontSize:11, color:'var(--c-text3)',
        padding:'6px 0 4px' }}>
        {BRAND.rulesVersion} · {BRAND.dataDate}
      </div>

      <StageBar entity={entity} />
      <ScoreTraj entity={entity} />
      <UpcomingDeadlines entity={entity} />

      <div style={{ height:24 }} />

      <PersonalTimeline entity={entity} />

      <p className="disclaimer">{BRAND.disclaimer}<br />{BRAND.rulesVersion} · {BRAND.dataDate}</p>
    </div>
  )
}
