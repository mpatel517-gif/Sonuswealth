import { useEffect, useState } from 'react'
import { BRAND } from '../config/brand.js'

// Animated counter
function useCounter(target, duration = 2000) {
  const [val, setVal] = useState(0)
  useEffect(() => {
    let frame
    const start = performance.now()
    function tick(now) {
      const p = Math.min(1, (now - start) / duration)
      const ease = 1 - Math.pow(1 - p, 3)
      setVal(Math.round(ease * target))
      if (p < 1) frame = requestAnimationFrame(tick)
      else setVal(target)
    }
    frame = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(frame)
  }, [target, duration])
  return val
}

function Stars() {
  const stars = Array.from({ length: 80 }, (_, i) => ({
    size:  Math.random() * 2.5 + 0.5,
    op:    (Math.random() * 0.6 + 0.2).toFixed(2),
    dur:   (Math.random() * 4 + 2).toFixed(1),
    delay: -(Math.random() * 4).toFixed(1),
    left:  Math.random() * 100,
    top:   Math.random() * 100,
  }))
  return (
    <div style={{ position:'absolute', inset:0, overflow:'hidden', pointerEvents:'none' }}>
      <style>{`
        @keyframes twinkle { 0%,100%{opacity:.1} 50%{opacity:.8} }
        @keyframes glowDrift { 0%,100%{transform:translate(0,0) scale(1)} 33%{transform:translate(30px,-40px) scale(1.05)} 66%{transform:translate(-20px,30px) scale(.95)} }
        @keyframes floatCard { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
      `}</style>
      {stars.map((s, i) => (
        <div key={i} style={{
          position:'absolute', borderRadius:'50%', background:'#fff',
          width: s.size, height: s.size,
          left: `${s.left}%`, top: `${s.top}%`,
          animation: `twinkle ${s.dur}s ease-in-out infinite ${s.delay}s`,
          opacity: s.op,
        }} />
      ))}
    </div>
  )
}

function GlowOrbs() {
  return (
    <div style={{ position:'absolute', inset:0, pointerEvents:'none', overflow:'hidden' }}>
      {[
        { w:400, h:400, bg:'rgba(0,229,168,.12)', top:'-100px', right:'-80px',  dur:'14s', delay:'0s'  },
        { w:300, h:300, bg:'rgba(77,142,255,.08)', bottom:'100px',left:'-60px', dur:'10s', delay:'-5s' },
        { w:200, h:200, bg:'rgba(0,229,168,.06)', top:'40%',  right:'20%',      dur:'16s', delay:'-8s' },
      ].map((g, i) => (
        <div key={i} style={{
          position:'absolute', borderRadius:'50%', filter:'blur(100px)',
          width:g.w, height:g.h, background:g.bg,
          top:g.top, right:g.right, bottom:g.bottom, left:g.left,
          animation: `glowDrift ${g.dur} ease-in-out infinite ${g.delay}`,
        }} />
      ))}
    </div>
  )
}

function MiniBars() {
  const maxH = 40
  const heights = [45, 62, 55, 78, 70, 88, 82, 95, 90, 100]
  return (
    <div style={{ display:'flex', gap:3, alignItems:'flex-end', height:'40px', marginBottom:14 }}>
      {heights.map((h, i) => {
        const px = Math.round((h / 100) * maxH)
        const colour = h > 80 ? 'var(--c-acc)' : h > 60 ? 'rgba(0,229,168,.5)' : 'rgba(0,229,168,.25)'
        return (
          <div key={i} style={{
            flex:1, height:`${px}px`,
            borderRadius:'3px 3px 0 0',
            background: colour,
          }} />
        )
      })}
    </div>
  )
}

// FIX: onDemo now navigates to PersonaSelect, not directly to Dashboard.
// FIX: Language changed from "FQ" to "Finio Score" throughout.
export default function Welcome({ onStart, onDemo }) {
  const scoreVal = useCounter(43)

  return (
    <div style={{
      position:'relative', minHeight:'100vh', background:'var(--c-bg)',
      display:'flex', flexDirection:'column',
      justifyContent:'flex-end',
      padding:'0 24px max(48px,env(safe-area-inset-bottom))',
      overflow:'hidden',
    }}>
      <Stars />
      <GlowOrbs />

      {/* Grid lines */}
      <div style={{
        position:'absolute', inset:0, pointerEvents:'none',
        backgroundImage:'linear-gradient(rgba(255,255,255,.015) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.015) 1px,transparent 1px)',
        backgroundSize:'48px 48px',
      }} />

      {/* Hero content */}
      <div style={{ position:'relative', zIndex:2, width:'100%' }}>

        {/* Logo */}
        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:48 }}>
          <div style={{
            width:44, height:44, background:'var(--c-acc)', borderRadius:12,
            display:'flex', alignItems:'center', justifyContent:'center',
            boxShadow:'var(--sh-acc)',
          }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M5 12h5M8 9v6M13 9h5l-2.5 3 2.5 3h-5" stroke="#0B1F3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <div style={{ fontSize:28, fontWeight:800, color:'var(--c-text)', letterSpacing:-1 }}>
            {BRAND.nameDisplay}
          </div>
        </div>

        {/* Headline — FIX: removed "Quotient" language */}
        <div style={{ fontSize:44, fontWeight:800, color:'var(--c-text)', lineHeight:1.08, letterSpacing:-2, marginBottom:14 }}>
          Your<br /><span style={{ color:'var(--c-acc)' }}>Financial</span><br />Intelligence
        </div>
        <div style={{ fontSize:15, color:'var(--c-text2)', lineHeight:1.6, marginBottom:36, maxWidth:320 }}>
          One score. Every dimension of your financial life. From your first ISA to your estate — {BRAND.name} grows with you.
        </div>

        {/* Score Preview card — FIX: "Finio Score" not "FQ Score" */}
        <div style={{
          background:'var(--c-surface)', border:'1px solid var(--c-border2)',
          borderRadius:24, padding:20, marginBottom:28,
          boxShadow:'var(--sh2)',
          animation:'floatCard 6s ease-in-out infinite',
        }}>
          <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:16 }}>
            <div>
              <div style={{ fontSize:11, fontWeight:700, color:'var(--c-text3)', textTransform:'uppercase', letterSpacing:1.2, marginBottom:4 }}>
                Your Finio Score
              </div>
              <div style={{ fontSize:52, fontWeight:800, color:'var(--c-acc)', letterSpacing:-3, lineHeight:1 }}>
                {scoreVal}<span style={{ fontSize:16, color:'var(--c-text3)', fontWeight:400 }}> /100</span>
              </div>
            </div>
            <div style={{
              background:'var(--c-acc-bg)', color:'var(--c-acc)',
              fontSize:11, fontWeight:700, padding:'5px 10px', borderRadius:20,
              border:'1px solid rgba(0,229,168,.2)',
            }}>
              Established 🌱
            </div>
          </div>

          <MiniBars />

          {/* 3 metrics */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8 }}>
            {[
              { val:'43',    colour:'var(--c-acc)',  lbl:'Your score' },
              { val:'351',   colour:'var(--c-acc3)', lbl:'Days left'  },
              { val:'£340k', colour:'var(--c-gold)', lbl:'At risk'    },
            ].map(m => (
              <div key={m.lbl} style={{ background:'var(--c-surface2)', borderRadius:10, padding:'10px 8px', textAlign:'center' }}>
                <div style={{ fontSize:14, fontWeight:700, color: m.colour }}>{m.val}</div>
                <div style={{ fontSize:11, color:'var(--c-text3)', textTransform:'uppercase', letterSpacing:.5, marginTop:2 }}>{m.lbl}</div>
              </div>
            ))}
          </div>
        </div>

        {/* CTAs — FIX: onDemo → persona select, not dashboard directly */}
        <button onClick={onStart} style={{
          width:'100%', padding:17,
          background:'var(--c-acc)', color:'#0B1F3A',
          borderRadius:100, fontSize:16, fontWeight:700, letterSpacing:-.3,
          boxShadow:'var(--sh-acc)', marginBottom:10,
        }}>
          Discover your Finio Score — free
        </button>
        <button onClick={onDemo} style={{
          width:'100%', padding:14,
          background:'var(--c-surface)', border:'1px solid var(--c-border2)',
          color:'var(--c-text2)', borderRadius:100, fontSize:15, fontWeight:500,
        }}>
          View demo dashboard →
        </button>
      </div>
    </div>
  )
}
