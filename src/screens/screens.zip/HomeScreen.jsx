import { useState, useCallback, useEffect } from 'react'
import {
  calcFQ, calcRisk, fqTrajectory, trajectoryData,
  netWorth, costOfInaction, fmt, daysLeft,
  financialProfile, guardrail, TAX,
} from '../engine/fq-calculator.js'
import { simulate, netWorthImpact } from '../engine/simulator.js'
import SimulatorPanel from '../components/Dashboard/SimulatorPanel.jsx'
import FQBreakdown    from './FQBreakdown.jsx'
import TripleAnchor   from '../components/shared/TripleAnchor.jsx'
import { BRAND }      from '../config/brand.js'
import { DIMENSIONS, narrativeFor } from '../config/dimensions.js'

// ─────────────────────────────────────────────────────────────────────────────
// DIM_CONFIG is now derived from shared DIMENSIONS + per-entity narrative.
// Each function that needs it builds its own enriched copy with narrativeFor.
// ─────────────────────────────────────────────────────────────────────────────
function buildDimConfig(entity) {
  return DIMENSIONS.map(d => ({ ...d, ...narrativeFor(entity, d.key) }))
}

// ─────────────────────────────────────────────────────────────────────────────
// LEGACY DEMO OVERRIDE — preserved exactly as built. HomeScreen only.
// Do not propagate into fq-calculator.js.
// ─────────────────────────────────────────────────────────────────────────────
function calcFQCalibrated(e) {
  const base = calcFQ(e)
  const sippAtRisk = (e.assets?.sipp?.total || 0) >= 100000 &&
                     (e.drawdown || 0) === 0 &&
                     (e.age || 0) >= 60
  if (!sippAtRisk) return base
  const capital_capped = Math.min(13, base.dims.capital)
  const momentum_adj   = Math.max(0.82, base.momentum - 0.08)
  const raw = base.dims.behaviour + capital_capped + base.dims.tax +
              base.dims.protection + base.dims.cashflow +
              base.dims.debt + base.dims.estate
  const total = Math.min(100, Math.max(0, Math.round(raw * momentum_adj)))
  return { ...base, total, dims: { ...base.dims, capital: capital_capped }, momentum: momentum_adj }
}

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────
function toRad(deg) { return deg * Math.PI / 180 }
function radarPt(cx, cy, r, deg) {
  return { x: cx + r * Math.cos(toRad(deg)), y: cy + r * Math.sin(toRad(deg)) }
}
function ringStyle(frac) {
  if (frac <= 0.10) return { fill:'rgba(255,59,48,0.28)',   stroke:'rgba(255,59,48,0.60)'   }
  if (frac <= 0.20) return { fill:'rgba(255,59,48,0.20)',   stroke:'rgba(255,59,48,0.45)'   }
  if (frac <= 0.35) return { fill:'rgba(255,107,107,0.16)', stroke:'rgba(255,107,107,0.38)' }
  if (frac <= 0.50) return { fill:'rgba(255,149,0,0.14)',   stroke:'rgba(255,149,0,0.32)'   }
  if (frac <= 0.65) return { fill:'rgba(255,179,71,0.12)',  stroke:'rgba(255,179,71,0.28)'  }
  if (frac <= 0.80) return { fill:'rgba(77,142,255,0.12)',  stroke:'rgba(77,142,255,0.30)'  }
  if (frac <= 0.90) return { fill:'rgba(0,229,168,0.12)',   stroke:'rgba(0,229,168,0.35)'   }
  return                   { fill:'rgba(0,229,168,0.20)',   stroke:'rgba(0,229,168,0.55)'   }
}
function getUrgency(entity, coi, dl) {
  if (entity.type === 'ifa') return null
  if (coi > 0 && dl > 0 && dl < 500)
    return { icon:'⏳', text:`${dl} days · ${fmt(coi)} at risk — model drawdown now`, level:'high', screen:'tax' }
  return null
}

// ─────────────────────────────────────────────────────────────────────────────
// JIT'S RADAR CHART — preserved exactly. Opens via toggle.
// ─────────────────────────────────────────────────────────────────────────────
function RadarChart({ entity, fqData, onDimTap, rippleDims }) {
  const [tooltip, setTooltip] = useState(null)
  const [centreHover, setCentreHover] = useState(false)
  const cx = 160, cy = 160, maxR = 115
  const DIM_CONFIG = buildDimConfig(entity)
  const fracs = DIM_CONFIG.map(d => ({
    ...d, score: fqData.dims[d.key] || 0, frac: Math.min(1, (fqData.dims[d.key] || 0) / d.max),
  }))
  const dataPts  = fracs.map(d => radarPt(cx, cy, Math.max(0.08, d.frac) * maxR, d.angle))
  const dataPath = dataPts.map((p,i) => `${i===0?'M':'L'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ') + ' Z'
  const rings    = [1.0,0.85,0.70,0.55,0.40,0.25,0.10]
  const nw       = netWorth(entity)
  return (
    <div style={{ position:'relative', width:'100%' }}>
      <svg viewBox="0 0 320 320" width="100%" style={{ overflow:'visible' }}>
        <defs><clipPath id="rc"><circle cx={cx} cy={cy} r={maxR+1}/></clipPath></defs>
        {rings.map(r => { const rs=ringStyle(r); return <circle key={r} cx={cx} cy={cy} r={r*maxR} fill={rs.fill} stroke={rs.stroke} strokeWidth="0.75"/> })}
        {[{frac:0.25,label:'25%'},{frac:0.50,label:'50%'},{frac:0.75,label:'75%'},{frac:1.0,label:'100%'}].map(rl=>(
          <text key={rl.label} x={cx+rl.frac*maxR-3} y={cy-4} fontSize="11" fill="rgba(138,155,192,0.5)" textAnchor="end" fontFamily="DM Sans,sans-serif">{rl.label}</text>
        ))}
        {DIM_CONFIG.map((d,i) => { const o=radarPt(cx,cy,maxR,d.angle); return <line key={i} x1={cx} y1={cy} x2={o.x.toFixed(1)} y2={o.y.toFixed(1)} stroke="rgba(138,155,192,0.10)" strokeWidth="0.75"/> })}
        <path d={dataPath} fill="rgba(255,255,255,0.06)" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5" strokeLinejoin="round" clipPath="url(#rc)"/>
        {dataPts.map((p,i) => {
          const d=fracs[i], pct=Math.round(d.frac*100), isActive=tooltip===i, isRippled=rippleDims?.includes(d.key), dotR=18
          return (
            <g key={i} style={{cursor:'pointer'}} onClick={()=>setTooltip(isActive?null:i)}>
              <circle cx={p.x} cy={p.y} r="26" fill="transparent"/>
              {isRippled && <circle cx={p.x} cy={p.y} r={dotR+6} fill="none" stroke={d.colour} strokeWidth="1.5" opacity="0.5" strokeDasharray="3 3"/>}
              <circle cx={p.x} cy={p.y} r={isActive?dotR+3:dotR} fill={d.colour} stroke={isActive?'#fff':'rgba(8,14,26,0.6)'} strokeWidth={isActive?2:1.5} style={{transition:'all .15s'}}/>
              <text x={p.x} y={p.y+4} fontSize="11" fontWeight="700" fill={pct>60?'#0B1F3A':'#fff'} textAnchor="middle" fontFamily="DM Sans,sans-serif">{pct}%</text>
            </g>
          )
        })}
        {DIM_CONFIG.map((d,i) => {
          const lp=radarPt(cx,cy,maxR+22,d.angle), anchor=lp.x>cx+10?'start':lp.x<cx-10?'end':'middle'
          return <text key={i} x={lp.x} y={lp.y+4} fontSize="11" fontWeight="700" fill={d.colour} textAnchor={anchor} fontFamily="DM Sans,sans-serif">{d.label}</text>
        })}
        <circle cx={cx} cy={cy} r="36" fill="rgba(8,14,26,0.92)" stroke="rgba(255,255,255,0.12)" strokeWidth="1" style={{cursor:'pointer'}} onClick={()=>setCentreHover(!centreHover)}/>
        <text x={cx} y={cy+5} fontSize="14" fontWeight="800" fill="#F0F4FF" textAnchor="middle" fontFamily="DM Sans,sans-serif">{fmt(nw)}</text>
        {centreHover && (<g><rect x={cx-42} y={cy-58} width="84" height="24" rx="6" fill="rgba(17,28,46,0.96)" stroke="rgba(255,255,255,0.15)" strokeWidth="0.75"/><text x={cx} y={cy-42} fontSize="11" fill="rgba(240,244,255,0.8)" textAnchor="middle" fontFamily="DM Sans,sans-serif">Total net worth</text></g>)}
      </svg>
      {tooltip !== null && (() => {
        const d=fracs[tooltip], pct=Math.round(d.frac*100)
        return (
          <div style={{margin:'0 16px 4px',background:'var(--c-surface)',border:`1.5px solid ${d.colour}`,borderRadius:16,padding:'14px 16px',boxShadow:'0 4px 24px rgba(0,0,0,0.5)'}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}>
              <span style={{fontSize:15,fontWeight:700,color:d.colour}}>{d.label}</span>
              <span style={{fontSize:13,fontWeight:600,color:'var(--c-text)'}}>{d.score}/{d.max}<span style={{fontSize:11,color:'rgba(138,155,192,.6)',marginLeft:4}}>({pct}%)</span></span>
            </div>
            <div style={{display:'flex',flexDirection:'column',gap:6,marginBottom:12}}>
              <div style={{display:'flex',gap:8,alignItems:'flex-start'}}>
                <span style={{fontSize:11,fontWeight:700,color:'rgba(138,155,192,.5)',width:60,flexShrink:0,paddingTop:1}}>WHAT</span>
                <span style={{fontSize:13,color:'var(--c-text2)',lineHeight:1.5}}>{d.definition}</span>
              </div>
              <div style={{display:'flex',gap:8,alignItems:'flex-start'}}>
                <span style={{fontSize:11,fontWeight:700,color:'#FF9500',width:60,flexShrink:0,paddingTop:1}}>RISK</span>
                <span style={{fontSize:13,color:'var(--c-text2)',lineHeight:1.5}}>{d.risk}</span>
              </div>
            </div>
            <div style={{display:'flex',gap:8}}>
              <button onClick={e=>{e.stopPropagation();onDimTap(d.key);setTooltip(null)}} style={{flex:1,padding:'10px 0',borderRadius:10,fontSize:13,fontWeight:700,background:d.colour,color:pct>60?'#0B1F3A':'#fff',border:'none',cursor:'pointer'}}>Simulate →</button>
              <button onClick={e=>{e.stopPropagation();setTooltip(null)}} style={{padding:'10px 16px',borderRadius:10,fontSize:13,color:'rgba(138,155,192,.7)',background:'rgba(255,255,255,.06)',border:'1px solid rgba(255,255,255,.1)',cursor:'pointer'}}>✕</button>
            </div>
          </div>
        )
      })()}
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// NET WORTH TRAJECTORY — preserved exactly
// ─────────────────────────────────────────────────────────────────────────────
function NWTraj({ entity }) {
  const [callout, setCallout] = useState(null)
  const data=trajectoryData(entity), all=[...data.doNothing,...data.draw25,...data.draw377].map(d=>d.nw)
  const maxV=Math.max(...all), ages=data.doNothing.map(d=>d.age)
  const W=320,H=100,pL=6,pR=6,pT=8,pB=20,pw=W-pL-pR,ph=H-pT-pB
  const px=age=>pL+((age-ages[0])/(ages[ages.length-1]-ages[0]))*pw
  const py=nw=>pT+ph-((nw/maxV)*ph)
  function cr(pts){let d=`M${pts[0].x.toFixed(1)},${pts[0].y.toFixed(1)}`;for(let i=0;i<pts.length-1;i++){const p0=pts[Math.max(0,i-1)],p1=pts[i],p2=pts[i+1],p3=pts[Math.min(pts.length-1,i+2)];d+=` C${(p1.x+(p2.x-p0.x)/6).toFixed(1)},${(p1.y+(p2.y-p0.y)/6).toFixed(1)} ${(p2.x-(p3.x-p1.x)/6).toFixed(1)},${(p2.y-(p3.y-p1.y)/6).toFixed(1)} ${p2.x.toFixed(1)},${p2.y.toFixed(1)}`}return d}
  const guard = Math.round(guardrail(entity))
  const brl   = TAX?.brl || 50270
  const draw25 = Math.min(25000, guard)
  const draw37 = Math.min(brl - 11973, guard)
  const series=[{d:data.doNothing,c:'#FF6B6B',w:1.8,label:'Do nothing'},{d:data.draw25,c:'#4D8EFF',w:2.0,label:`Draw ${fmt(draw25)}/yr`},{d:data.draw377,c:'#00E5A8',w:2.5,label:`Draw ${fmt(draw37)}/yr`}]
  return (
    <div style={{margin:'0 16px 10px',background:'var(--c-surface)',border:'1px solid rgba(255,255,255,.06)',borderRadius:20,padding:16}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:4}}>
        <div style={{fontSize:13,fontWeight:700,color:'var(--c-text)'}}>Net worth to age 90</div>
        <div style={{display:'flex',gap:10}}>{series.map(s=><div key={s.label} style={{display:'flex',alignItems:'center',gap:4,fontSize:11,color:'rgba(138,155,192,.7)'}}><div style={{width:12,height:3,borderRadius:100,background:s.c}}/>{s.label}</div>)}</div>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" style={{overflow:'visible'}}>
        {ages.map(a=><text key={a} x={px(a).toFixed(0)} y={H} textAnchor="middle" fontSize="11" fill="#4A5878" fontFamily="DM Sans,sans-serif">{a}</text>)}
        {series.map(s=>{const pts=s.d.map(p=>({x:px(p.age),y:py(p.nw)}));return <path key={s.label} d={cr(pts)} fill="none" stroke={s.c} strokeWidth={s.w} strokeLinecap="round"/>})}
        {data.draw377.map(p=><circle key={p.age} cx={px(p.age).toFixed(1)} cy={py(p.nw).toFixed(1)} r="3" fill="#00E5A8" stroke="rgba(8,14,26,.8)" strokeWidth="1.5" onClick={()=>setCallout(callout?.age===p.age?null:p.age)} style={{cursor:'pointer'}}/>)}
        {ages.map(a=><circle key={a} cx={px(a).toFixed(1)} cy="50" r="16" fill="transparent" onClick={()=>setCallout(callout?.age===a?null:a)}/>)}
      </svg>
      {callout&&(()=>{const dn=data.doNothing.find(p=>p.age===callout),d25=data.draw25.find(p=>p.age===callout),d37=data.draw377.find(p=>p.age===callout);return(<div style={{background:'rgba(23,32,54,.98)',border:'1px solid rgba(255,255,255,.1)',borderRadius:10,padding:'10px 12px',marginTop:8}}><div style={{fontSize:13,fontWeight:700,color:'var(--c-text)',marginBottom:5}}>Age {callout}</div><div style={{display:'flex',gap:12,flexWrap:'wrap'}}><span style={{fontSize:13,fontWeight:600,color:'#FF6B6B'}}>Do nothing: {fmt(dn?.nw)}</span><span style={{fontSize:13,fontWeight:600,color:'#4D8EFF'}}>{fmt(draw25)}/yr: {fmt(d25?.nw)}</span><span style={{fontSize:13,fontWeight:600,color:'#00E5A8'}}>{fmt(draw37)}/yr: {fmt(d37?.nw)}</span></div></div>)})()}
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// ALERT CARDS — preserved exactly
// ─────────────────────────────────────────────────────────────────────────────
function AlertCards({ entity, onNav }) {
  return (
    <>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'16px 16px 8px'}}>
        <div style={{fontSize:11,fontWeight:700,color:'rgba(138,155,192,.7)',textTransform:'uppercase',letterSpacing:.8}}>Active insights</div>
        <div style={{fontSize:13,fontWeight:600,color:'#00E5A8',cursor:'pointer'}}>{entity.alerts?.length||0} alerts</div>
      </div>
      {(entity.alerts||[]).map((a,i)=>(
        <div key={i} className={`alert-card ${a.level}`} onClick={()=>onNav?.(a.screen||'ask')}>
          <div className="ac-inner">
            <div className="ac-top"><div className="ac-badge">{a.badge}</div><div className="ac-days">{a.days}</div></div>
            <div className="ac-title">{a.headline}</div>
            <div className="ac-body">{a.context}</div>
            <div className="ac-foot"><div className="ac-cta">{a.action}</div><span style={{color:'rgba(138,155,192,.6)',fontSize:16}}>›</span></div>
          </div>
        </div>
      ))}
    </>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// ANIMATED NET WORTH COUNTER
// ─────────────────────────────────────────────────────────────────────────────
function useCount(target, duration = 1000) {
  const [val, setVal] = useState(0)
  useEffect(() => {
    let frame
    const start = performance.now()
    function tick(now) {
      const p    = Math.min(1, (now - start) / duration)
      const ease = 1 - Math.pow(1 - p, 3)
      setVal(Math.round(ease * target))
      if (p < 1) frame = requestAnimationFrame(tick)
      else setVal(target)
    }
    frame = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(frame)
  }, [target, duration])
  return val
}

// ─────────────────────────────────────────────────────────────────────────────
// TWIN ANCHOR CARD
// Net Worth = hero. Finio Score = secondary. Profile cell = plain English.
// ─────────────────────────────────────────────────────────────────────────────
function DimBars({ entity, fqData, onDimTap, rippleDims }) {
  const DIM_CONFIG = buildDimConfig(entity)
  return (
    <div style={{
      margin: '0 16px 10px',
      background: 'var(--c-surface)',
      border: '1px solid rgba(255,255,255,0.07)',
      borderRadius: 20,
      padding: '16px 18px',
    }}>
      <div style={{ fontSize:11, fontWeight:700, color:'var(--c-text3)', textTransform:'uppercase', letterSpacing:0.8, marginBottom:14 }}>
        {BRAND.finioScore} · 7 dimensions
      </div>
      {DIM_CONFIG.map((d, i) => {
        const score      = fqData.dims[d.key] || 0
        const pct        = Math.round((score / d.max) * 100)
        const isRippled  = rippleDims?.includes(d.key)
        const isLast     = i === DIM_CONFIG.length - 1
        return (
          <div
            key={d.key}
            onClick={() => onDimTap(d.key)}
            style={{ display:'flex', alignItems:'center', gap:10, marginBottom: isLast ? 0 : 9, cursor:'pointer', padding:'1px 0' }}
          >
            {/* Colour dot */}
            <div style={{
              width:7, height:7, borderRadius:'50%', flexShrink:0,
              background: d.colour,
              boxShadow: isRippled ? `0 0 8px ${d.colour}88` : 'none',
              transition: 'box-shadow 0.4s',
            }} />
            {/* Label */}
            <div style={{ fontSize:13, color:'var(--c-text2)', width:66, flexShrink:0 }}>
              {d.label}
            </div>
            {/* Bar track */}
            <div style={{ flex:1, height:5, background:'rgba(255,255,255,0.07)', borderRadius:100, overflow:'hidden' }}>
              <div style={{
                height:'100%', borderRadius:100,
                width:`${pct}%`,
                background: d.colour,
                opacity: 0.82,
                transition: 'width 0.7s cubic-bezier(0.4,0,0.2,1)',
              }} />
            </div>
            {/* Score */}
            <div style={{ fontSize:11, fontWeight:700, color: d.colour, width:34, textAlign:'right', flexShrink:0 }}>
              {score}/{d.max}
            </div>
          </div>
        )
      })}
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// HOME SCREEN — main export
// ─────────────────────────────────────────────────────────────────────────────
export default function HomeScreen({ entity, onNav }) {
  const [showBreakdown, setShowBreakdown] = useState(false)
  const [breakdownTab,  setBreakdownTab]  = useState('radar')
  const [activeDimKey,  setActiveDimKey]  = useState(null)
  const [panelOpen,     setPanelOpen]     = useState(false)
  const [simResult,     setSimResult]     = useState(null)
  const [rippleDims,    setRippleDims]    = useState([])

  const baseFQData  = calcFQCalibrated(entity)
  const fqData      = simResult ? simResult.fqData : baseFQData
  const riskData    = calcRisk(entity)
  const coi         = costOfInaction(entity)
  const dl          = daysLeft()
  const urgency     = getUrgency(entity, coi, dl)
  const traj        = fqTrajectory(entity)
  const isSimulating= simResult !== null
  const deltaFQ     = simResult ? simResult.deltaFQ : 0
  const nw          = netWorth(entity)

  // Safe financialProfile call — engine may not have it if not yet deployed
  let profile = null
  try { profile = financialProfile(entity) } catch {}

  const handleDimTap = useCallback((dimKey) => {
    setActiveDimKey(dimKey); setPanelOpen(true)
  }, [])

  const handleSimulate = useCallback((result) => {
    setSimResult(result); setRippleDims(result.rippleDims || [])
  }, [])

  const handlePanelClose = useCallback(() => { setPanelOpen(false) }, [])

  const handleResetSim = useCallback(() => {
    setSimResult(null); setRippleDims([]); setActiveDimKey(null); setPanelOpen(false)
  }, [])

  return (
    <>
      {/* Rules label */}
      <div style={{ textAlign:'right', fontSize:'var(--fs-label)', color:'var(--c-text3)',
        padding:'6px 16px 0', textTransform:'uppercase', letterSpacing:0.8 }}>
        {BRAND.rulesVersion} · {BRAND.dataDate}
      </div>

      {/* ── TRIPLE ANCHOR — shared component ──────────────────────────────── */}
      <TripleAnchor
        netWorthVal={nw}
        fqTotal={fqData.total}
        fqBand={fqData.band}
        riskTotal={riskData.total}
        riskBand={riskData.band}
        deltaFQ={deltaFQ}
        isSimulating={isSimulating}
      />

      {/* ── DIMENSION BARS — visual first ──────────────────────────────────── */}
      <DimBars entity={entity} fqData={fqData} onDimTap={handleDimTap} rippleDims={rippleDims} />

      {/* ── COST OF INACTION STRIP ─────────────────────────────────────────── */}
      {coi > 0 && dl > 0 && (
        <div style={{ margin:'0 16px 10px', textAlign:'center', fontSize:13, fontWeight:600, color:'rgba(255,149,0,.9)', letterSpacing:.2 }}>
          Cost of inaction: {fmt(coi)} · {dl} days to act
        </div>
      )}

      {/* ── URGENCY STRIP ──────────────────────────────────────────────────── */}
      {urgency && (
        <div onClick={() => onNav?.(urgency.screen)} style={{ margin:'0 16px 10px', background:'rgba(255,149,0,.1)', borderLeft:'4px solid #FF9500', borderRadius:'0 12px 12px 0', padding:'10px 14px', display:'flex', alignItems:'center', gap:10, cursor:'pointer' }}>
          <span style={{ fontSize:18, flexShrink:0 }}>{urgency.icon}</span>
          <span style={{ fontSize:13, fontWeight:600, color:'var(--c-text)', lineHeight:1.4, flex:1 }}>{urgency.text}</span>
          <span style={{ fontSize:16, color:'rgba(138,155,192,.6)', flexShrink:0 }}>›</span>
        </div>
      )}

      {/* ── STAT PILLS ─────────────────────────────────────────────────────── */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr 1fr', gap:6, margin:'0 16px 10px' }}>
        {[
          { val:fmt(nw),                      colour:'var(--c-text)', lbl:'Net worth'  },
          { val:fmt(coi),                     colour:'#FF6B6B',       lbl:'At risk'    },
          { val:String(dl),                   colour:'#FF9500',       lbl:'Days left'  },
          { val:String(entity.alerts?.length||0), colour:'#00E5A8',   lbl:'Actions'    },
        ].map(s => (
          <div key={s.lbl} style={{ background:'var(--c-surface2)', borderRadius:10, padding:'8px 6px', textAlign:'center' }}>
            <div style={{ fontSize:13, fontWeight:700, color:s.colour }}>{s.val}</div>
            <div style={{ fontSize:11, color:'rgba(138,155,192,.6)', textTransform:'uppercase', letterSpacing:.4, marginTop:2 }}>{s.lbl}</div>
          </div>
        ))}
      </div>

      {/* ── FQ JOURNEY ─────────────────────────────────────────────────────── */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'4px 16px 8px' }}>
        <div style={{ fontSize:11, fontWeight:700, color:'rgba(138,155,192,.7)', textTransform:'uppercase', letterSpacing:.8 }}>Score journey</div>
        <button onClick={() => { setBreakdownTab('radar'); setShowBreakdown(true) }} style={{ background:'none', border:'none', cursor:'pointer', fontSize:13, fontWeight:600, color:'#00E5A8', padding:0 }}>
          Radar view →
        </button>
      </div>
      <div style={{ margin:'0 16px 10px', background:'var(--c-surface)', border:'1px solid rgba(255,255,255,.06)', borderRadius:16, padding:14 }}>
        <div style={{ display:'flex', justifyContent:'space-between', marginBottom:10 }}>
          {traj.map(t => (
            <div key={t.label} style={{ textAlign:'center' }}>
              <div style={{ fontSize:18, fontWeight:800, color:t.colour }}>{t.score}</div>
              <div style={{ fontSize:11, color:'rgba(138,155,192,.6)', marginTop:2 }}>{t.label}</div>
            </div>
          ))}
        </div>
        <div style={{ height:4, background:'rgba(255,255,255,.06)', borderRadius:100, overflow:'hidden' }}>
          <div style={{ height:'100%', width:`${baseFQData.total}%`, background:'linear-gradient(90deg,#FF6B6B,#FFB347,#4D8EFF,#00E5A8)', borderRadius:100 }} />
        </div>
        <div style={{ fontSize:11, color:'rgba(138,155,192,.6)', marginTop:8 }}>
          Start drawdown → score <strong style={{ color:'#4D8EFF' }}>{traj[2]?.score}</strong> in 6 months · All actions → <strong style={{ color:'#00E5A8' }}>{traj[3]?.score}</strong>
        </div>
      </div>

      {/* ── NET WORTH TRAJECTORY ───────────────────────────────────────────── */}
      <NWTraj entity={entity} />

      {/* ── ALERT CARDS ────────────────────────────────────────────────────── */}
      <AlertCards entity={entity} onNav={onNav} />

      {/* ── DISCLAIMER ─────────────────────────────────────────────────────── */}
      <div style={{ textAlign:'center', fontSize:11, color:'rgba(138,155,192,.5)', padding:'14px 24px 8px', lineHeight:1.6 }}>
        {BRAND.disclaimer}<br />{BRAND.rulesVersion} · Last verified: {BRAND.dataDate}
      </div>
      <div style={{ height:12 }} />

      {/* ── SIMULATOR PANEL ────────────────────────────────────────────────── */}
      {panelOpen && activeDimKey && (
        <div style={{ margin:'12px 0 0', borderRadius:'20px 20px 0 0', overflow:'hidden', boxShadow:'0 -4px 40px rgba(0,0,0,0.5)' }}>
          <SimulatorPanel
            entity={entity}
            activeDimKey={activeDimKey}
            baseFQTotal={baseFQData.total}
            onSimulate={handleSimulate}
            onClose={handlePanelClose}
          />
        </div>
      )}

      {/* ── JIT'S RADAR — via toggle ────────────────────────────────────────── */}
      {showBreakdown && (
        <FQBreakdown
          entity={entity}
          initialTab={breakdownTab}
          activeDimKey={activeDimKey}
          onClose={() => { setShowBreakdown(false); setBreakdownTab('radar') }}
        />
      )}
    </>
  )
}
