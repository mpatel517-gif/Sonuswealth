import { useState } from 'react'
import {
  fmt, daysLeft, costOfInaction,
  ihtDynamic, sippProjection, incomeTax,
  giftPct, taperBand, netWorth, guardrail, TAX,
} from '../engine/fq-calculator.js'
import { BRAND } from '../config/brand.js'

// ── Constants ─────────────────────────────────────────────────────────────
const DEADLINE_LABEL = '6 April 2027'
const DEADLINE_TOTAL_DAYS = 365

// ── Jurisdiction helpers ──────────────────────────────────────────────────
// UK SIPP IHT deadline applies to UK tax residents.
// Priya (NRI) is UK resident (primary jurisdiction = UK) so countdown IS relevant.
// If entity has jurisdiction flag set to non-UK, suppress UK-specific content.
function isNRI(entity) {
  return entity.type === 'nri'
}

// ── NRI jurisdiction notice ───────────────────────────────────────────────
function NRINotice() {
  return (
    <div style={{
      margin:'0 0 12px',
      background:'rgba(77,142,255,.07)',
      border:'1px solid rgba(77,142,255,.25)',
      borderRadius:16, padding:'14px 16px',
    }}>
      <div style={{ fontSize:11, fontWeight:700, color:'#4D8EFF',
        textTransform:'uppercase', letterSpacing:1, marginBottom:6 }}>
        NRI / Cross-border view
      </div>
      <div style={{ fontSize:13, color:'var(--c-text2)', lineHeight:1.6 }}>
        Showing UK calculations for your UK-resident position. Indian-specific tax features
        (NPS, LTCG, NRE/NRO treatment, DTAA optimisation) coming in the India bundle.
        Your SIPP and UK estate are calculated correctly below.
      </div>
    </div>
  )
}

// ── Countdown bar ─────────────────────────────────────────────────────────
function CountdownBar({ days }) {
  const pct     = Math.max(0, Math.min(100, (days / DEADLINE_TOTAL_DAYS) * 100))
  const urgent  = days < 90
  const warning = days < 180
  const colour  = urgent ? '#FF3B30' : warning ? '#FF9500' : '#FFB347'

  return (
    <div className="card" style={{ marginBottom:12 }}>
      <div style={{ display:'flex', justifyContent:'space-between',
        alignItems:'flex-start', marginBottom:12 }}>
        <div>
          <div style={{ fontSize:11, fontWeight:700, color:colour,
            textTransform:'uppercase', letterSpacing:1, marginBottom:4 }}>
            DC pension enters estate
          </div>
          <div style={{ fontSize:28, fontWeight:900, color:colour,
            letterSpacing:-1 }}>
            {days} days
          </div>
          <div style={{ fontSize:11, color:'var(--c-text3)', marginTop:2 }}>
            Deadline: {DEADLINE_LABEL}
          </div>
        </div>
        <div style={{ fontSize:36 }}>⏳</div>
      </div>
      {/* Shrinking bar — filled portion = time remaining */}
      <div style={{ height:8, background:'rgba(255,255,255,.07)',
        borderRadius:100, overflow:'hidden' }}>
        <div style={{
          height:'100%', borderRadius:100,
          width:`${pct}%`,
          background:`linear-gradient(90deg, ${colour}66, ${colour})`,
          transition:'width 1s ease',
        }} />
      </div>
      <div style={{ display:'flex', justifyContent:'space-between',
        fontSize:11, color:'var(--c-text3)', marginTop:4 }}>
        <span>Today</span>
        <span>{DEADLINE_LABEL}</span>
      </div>
    </div>
  )
}

// ── Cost of Inaction hero ─────────────────────────────────────────────────
function CoIHero({ coi, days }) {
  return (
    <div style={{
      margin:'0 0 12px',
      background:'rgba(255,59,48,.07)',
      border:'1px solid rgba(255,59,48,.30)',
      borderRadius:20, padding:'20px 20px 16px',
    }}>
      <div style={{ fontSize:11, fontWeight:700, color:'#FF3B30',
        textTransform:'uppercase', letterSpacing:1, marginBottom:6 }}>
        Cost of Inaction
      </div>
      <div style={{ fontSize:44, fontWeight:900, color:'#FF3B30',
        letterSpacing:-2, lineHeight:1, marginBottom:8 }}>
        {fmt(coi)}
      </div>
      <div style={{ fontSize:13, color:'var(--c-text2)', lineHeight:1.6 }}>
        This is the extra inheritance tax your estate will pay if you take no action before {DEADLINE_LABEL}. Every day of inaction costs <strong style={{ color:'#FF3B30' }}>{fmt(Math.round(coi / Math.max(1, days)))}</strong>.
      </div>
    </div>
  )
}

// ── Drawdown scenario card ────────────────────────────────────────────────
function ScenarioCard({ label, drawdown, entity, isOptimal, isHighlight }) {
  const a         = entity.assets || {}
  const sipp      = a.sipp?.total || 0
  const sp        = entity.income?.statePension?.annual || 11973
  const spAge     = entity.income?.statePension?.startAge || 67
  const age       = entity.age || 62
  const ihtWith   = ihtDynamic(entity, true,  drawdown).iht
  const ihtWithout= ihtDynamic(entity, false, drawdown).iht
  const ihtSaving = Math.max(0, ihtWith - ihtWithout)
  const taxPaid   = drawdown > 0 ? incomeTax(drawdown, age >= spAge ? sp : 0) : 0
  const netToHand = drawdown - taxPaid
  const sipp5yr   = sippProjection(sipp, a.sipp?.growth || 0.05, drawdown, 5)

  return (
    <div style={{
      background: isHighlight ? 'rgba(0,229,168,.06)' : 'var(--c-surface)',
      border: `1px solid ${isHighlight ? 'rgba(0,229,168,.35)' : 'var(--c-sep)'}`,
      borderRadius:16, padding:'14px 16px', marginBottom:8,
    }}>
      <div style={{ display:'flex', justifyContent:'space-between',
        alignItems:'center', marginBottom:10 }}>
        <div style={{ fontSize:13, fontWeight:700, color:'var(--c-text)' }}>
          {label}
        </div>
        {isOptimal && (
          <div style={{ fontSize:11, fontWeight:700, color:'#00E5A8',
            background:'rgba(0,229,168,.12)', padding:'3px 9px',
            borderRadius:100 }}>
            Recommended
          </div>
        )}
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr',
        gap:'8px 16px' }}>
        {[
          { label:'Annual drawdown', val: drawdown > 0 ? fmt(drawdown) : '—' },
          { label:'Tax paid',        val: drawdown > 0 ? fmt(taxPaid) : '—' },
          { label:'Net to hand',     val: drawdown > 0 ? fmt(netToHand) : '—' },
          { label:'IHT saving',      val: fmt(ihtWith) + ' exposure' },
          { label:'SIPP in 5 years', val: fmt(sipp5yr) },
        ].map(r => (
          <div key={r.label}>
            <div style={{ fontSize:11, color:'var(--c-text3)',
              textTransform:'uppercase', letterSpacing:.5,
              marginBottom:2 }}>{r.label}</div>
            <div style={{ fontSize:13, fontWeight:700, color:'var(--c-text)' }}>
              {r.val}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── Drawdown scenarios ────────────────────────────────────────────────────
function DrawdownScenarios({ entity }) {
  // D09 fix: use shared TAX object + guardrail helper — no more local dupes
  const optimalDD = Math.min(TAX.brl, guardrail(entity))

  return (
    <div className="card">
      <div className="card-title">Drawdown Scenarios</div>
      <div style={{ fontSize:13, color:'var(--c-text2)', marginBottom:12,
        lineHeight:1.6 }}>
        All three scenarios use the same pension pot. The difference is how much you withdraw annually and what that means for tax, IHT, and estate size.
      </div>
      <ScenarioCard label="Do Nothing"   drawdown={0}        entity={entity} />
      <ScenarioCard label="Start now — basic rate limit" drawdown={TAX.brl} entity={entity} isOptimal isHighlight />
      <ScenarioCard label="Guardrail rate" drawdown={Math.round(optimalDD)} entity={entity} />
    </div>
  )
}

// ── IHT planner ───────────────────────────────────────────────────────────
function IHTPlanner({ entity }) {
  const a           = entity.assets || {}
  const sipp        = a.sipp?.total || 0
  const [dd, setDD] = useState(entity.drawdown || 0)
  const ihtWith     = ihtDynamic(entity, true,  dd)
  const ihtWithout  = ihtDynamic(entity, false, dd)
  const coi         = Math.max(0, ihtWith.iht - ihtWithout.iht)
  const guard       = Math.round(guardrail(entity))

  return (
    <div className="card">
      <div style={{ display:'flex', justifyContent:'space-between',
        alignItems:'center', marginBottom:12 }}>
        <div className="card-title" style={{ marginBottom:0 }}>IHT Planner</div>
        <div style={{ fontSize:11, color:'var(--c-text3)' }}>
          Live · UK-2026.1
        </div>
      </div>

      {/* FIX 5.3: Only show drawdown slider if SIPP exists.
          Avoids a 0→0 broken slider for Hermione (D), Anna age 22 (F), etc.
          D02 / DQ-44: drawdown cap is the pension pot itself (no arbitrary
          £80k), with a guardrail × 2 warning band surfaced below. */}
      {sipp > 0 ? (
        <div style={{ marginBottom:16 }}>
          <div style={{ display:'flex', justifyContent:'space-between',
            marginBottom:6 }}>
            <span style={{ fontSize:13, color:'var(--c-text2)' }}>Annual drawdown</span>
            <span style={{ fontSize:14, fontWeight:700, color:'var(--c-text)' }}>
              {fmt(dd)}
            </span>
          </div>
          <input type="range" min={0} max={sipp} step={500}
            value={dd}
            onChange={e => setDD(Number(e.target.value))}
            style={{ width:'100%', accentColor:'var(--c-acc)' }}
          />
          <div style={{ display:'flex', justifyContent:'space-between',
            fontSize:11, color:'var(--c-text3)', marginTop:3 }}>
            <span>£0</span>
            <span style={{ color:'#4D8EFF' }}>£37,700 basic rate</span>
            <span>{fmt(sipp)}</span>
          </div>
          {dd > guard * 2 && (
            <div style={{
              marginTop:8, padding:'8px 10px',
              background:'rgba(255,179,71,0.08)',
              border:'1px solid rgba(255,179,71,0.35)',
              borderRadius:8, fontSize:12, color:'#FFB347', lineHeight:1.5,
            }}>
              ⚠ Above twice your safe withdrawal rate ({fmt(guard)}/yr).
              Possible — but depletes capital faster than sustainable.
            </div>
          )}
        </div>
      ) : (
        <div style={{
          marginBottom:16, padding:'12px 14px',
          background:'var(--c-surface2)', borderRadius:12,
          fontSize:13, color:'var(--c-text3)', lineHeight:1.5,
        }}>
          No pension (SIPP/DC) recorded for this persona. IHT calculation uses property, ISA, and portfolio assets.
        </div>
      )}

      {/* Results grid */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr',
        gap:10, marginBottom:12 }}>
        {[
          { label:'Estate (gross)',       val: fmt(ihtWith.gross),   colour:'var(--c-text)' },
          { label:'IHT bill',             val: fmt(ihtWith.iht),     colour:'#FF3B30' },
          { label:'Family receives',      val: fmt(ihtWith.gross - ihtWith.iht), colour:'#00E5A8' },
          { label:'Pension IHT portion',  val: fmt(ihtWith.sippContribution || 0), colour:'#FF9500' },
        ].map(r => (
          <div key={r.label} style={{ background:'var(--c-surface2)',
            borderRadius:12, padding:'10px 12px' }}>
            <div style={{ fontSize:11, color:'var(--c-text3)',
              textTransform:'uppercase', letterSpacing:.5, marginBottom:3 }}>
              {r.label}
            </div>
            <div style={{ fontSize:16, fontWeight:700, color:r.colour }}>
              {r.val}
            </div>
          </div>
        ))}
      </div>

      {coi > 0 && (
        <div style={{ background:'rgba(255,59,48,.08)',
          border:'1px solid rgba(255,59,48,.25)', borderRadius:10,
          padding:'8px 12px', fontSize:13, color:'#FF3B30', fontWeight:600 }}>
          Pension cost of inaction at this drawdown rate: {fmt(coi)}
        </div>
      )}
    </div>
  )
}

// ── Gift tracker ──────────────────────────────────────────────────────────
function GiftTracker({ entity }) {
  const tg = entity.assets?.trustGifts
  if (!tg?.date) return null

  const pct  = giftPct(tg.date)
  const taper = taperBand(tg.date)

  return (
    <div className="card">
      <div className="card-title">Trust Gift Tracker</div>
      <div style={{ marginBottom:12 }}>
        <div style={{ display:'flex', justifyContent:'space-between',
          alignItems:'center', marginBottom:6 }}>
          <span style={{ fontSize:13, color:'var(--c-text2)' }}>
            {fmt(tg.total)} gifted {tg.date}
          </span>
          <span style={{ fontSize:13, fontWeight:700,
            color:'#00E5A8' }}>{pct}% of 7 years</span>
        </div>
        <div style={{ height:8, background:'rgba(255,255,255,.07)',
          borderRadius:100, overflow:'hidden' }}>
          <div style={{ width:`${pct}%`, height:'100%',
            background:'linear-gradient(90deg, #4D8EFF, #00E5A8)',
            borderRadius:100 }} />
        </div>
      </div>

      {/* Taper bands */}
      <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
        {[
          { label:'0–3 yrs', rate:'40%',  active: pct < 43 },
          { label:'3–4 yrs', rate:'32%',  active: pct >= 43 && pct < 57 },
          { label:'4–5 yrs', rate:'24%',  active: pct >= 57 && pct < 71 },
          { label:'5–6 yrs', rate:'16%',  active: pct >= 71 && pct < 86 },
          { label:'6–7 yrs', rate:'8%',   active: pct >= 86 && pct < 100 },
          { label:'7+ yrs',  rate:'0%',   active: pct >= 100 },
        ].map(b => (
          <div key={b.label} style={{ display:'flex',
            alignItems:'center', gap:10,
            opacity: b.active ? 1 : 0.4 }}>
            <div style={{ width:6, height:6, borderRadius:'50%', flexShrink:0,
              background: b.active ? '#00E5A8' : 'var(--c-text3)' }} />
            <div style={{ flex:1, fontSize:13,
              color: b.active ? 'var(--c-text)' : 'var(--c-text3)',
              fontWeight: b.active ? 600 : 400 }}>
              {b.label}
            </div>
            <div style={{ fontSize:13, fontWeight:700,
              color: b.rate === '0%' ? '#00E5A8' : b.active ? '#FFB347' : 'var(--c-text3)' }}>
              {b.rate} IHT
            </div>
          </div>
        ))}
      </div>

      <div style={{ marginTop:12, fontSize:13, color:'var(--c-text2)',
        lineHeight:1.6 }}>
        Current position: <strong style={{ color:'#FFB347' }}>
        {taper.label}</strong> · {fmt(Math.round(tg.total * taper.rate))} IHT if you died today.
      </div>
    </div>
  )
}

// ── Main export ───────────────────────────────────────────────────────────
export default function TaxEstate({ entity }) {
  const days = daysLeft()
  const coi  = costOfInaction(entity)
  const sipp = entity.assets?.sipp?.total || 0
  const nri  = isNRI(entity)

  return (
    <div className="screen">
      <div style={{ textAlign:'right', fontSize:11, color:'var(--c-text3)',
        padding:'6px 0 4px' }}>
        {BRAND.rulesVersion} · {BRAND.dataDate}
      </div>

      {/* FIX 5.1: NRI notice shown for Priya — India bundle not yet loaded */}
      {nri && <NRINotice />}

      {/* ── Countdown — shown for all UK-resident personas including NRI ── */}
      <CountdownBar days={days} />

      {/* ── Cost of Inaction ──────────────────────────────────────────── */}
      {coi > 0 && <CoIHero coi={coi} days={days} />}

      {/* ── Drawdown scenarios — only if SIPP exists ──────────────────── */}
      {sipp > 0 && <DrawdownScenarios entity={entity} />}

      {/* ── IHT planner — always shown, handles no-SIPP case internally ─ */}
      <IHTPlanner entity={entity} />

      {/* ── Gift tracker ──────────────────────────────────────────────── */}
      <GiftTracker entity={entity} />

      <p className="disclaimer">{BRAND.disclaimer}<br />{BRAND.rulesVersion} · {BRAND.dataDate}</p>
    </div>
  )
}
